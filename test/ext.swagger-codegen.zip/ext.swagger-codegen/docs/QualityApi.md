# sdk.QualityApi

All URIs are relative to */api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**do_configure_av_probe**](QualityApi.md#do_configure_av_probe) | **POST** /quality/configure_av_probe/{slot_id} | Configures an A/V probe at the content packager or transcoder or DUT&#x27;s HDMI to start A/V Sync calculations
[**get_pull_look_data**](QualityApi.md#get_pull_look_data) | **GET** /quality/pull_look_data/{slot_id} | Retrieves all of the data for a look ID, as defined via the Insights Portal UI
[**get_quality_metrics**](QualityApi.md#get_quality_metrics) | **GET** /quality/quality_metrics/{slot_id} | Retrieves SSIMWAVE quality metrics for a service that has this DUT&#x27;s service name, for a specific time window
[**get_signal_metrics**](QualityApi.md#get_signal_metrics) | **GET** /quality/signal_metrics/{slot_id} | Retrieves all audio/video signal quality metrics recorded by SSIMWAVE for this DUT

# **do_configure_av_probe**
> list[object] do_configure_av_probe(slot_id, transcoder_config=transcoder_config)

Configures an A/V probe at the content packager or transcoder or DUT's HDMI to start A/V Sync calculations

SDK: `do_configure_av_probe()`  Notes:  * For transcoder probes, specify `transcoder_config`.  * For HDMI probes do not specify any parameters as only the HDMI probe for the DUT can be configured and the    configuration will be dynamically determined.  * Doing both packager and transcoder simultaneously is not supported.  * Comparing HDMI to HDMI is not supported at this time.  * Once probes are created, it may take up to two minutes for A/V Sync data to become available (assuming the    various probes that have been configured actually are in sync).

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.QualityApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
transcoder_config = 'transcoder_config_example' # str | Dictionary specifying transcoder configuration --                            For transcoder input:                             - multicast_address: primary source address                             - port: primary source port                             - ssm_ip: multicast source IP address                            (e.g. dict(multicast_address=\"232.39.212.212\", port=21271, ssm_ip=\"10.44.241.70\"))                            For transcoder output:                             - multicast_address: destination address                             - port: destination port                             - ssm_ip: output source address                            (e.g. dict(multicast_address=\"236.32.247.94\", port=32000, ssm_ip=\"10.131.159.25\")) (optional)

try:
    # Configures an A/V probe at the content packager or transcoder or DUT's HDMI to start A/V Sync calculations
    api_response = api_instance.do_configure_av_probe(slot_id, transcoder_config=transcoder_config)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling QualityApi->do_configure_av_probe: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **transcoder_config** | **str**| Dictionary specifying transcoder configuration --                            For transcoder input:                             - multicast_address: primary source address                             - port: primary source port                             - ssm_ip: multicast source IP address                            (e.g. dict(multicast_address&#x3D;\&quot;232.39.212.212\&quot;, port&#x3D;21271, ssm_ip&#x3D;\&quot;10.44.241.70\&quot;))                            For transcoder output:                             - multicast_address: destination address                             - port: destination port                             - ssm_ip: output source address                            (e.g. dict(multicast_address&#x3D;\&quot;236.32.247.94\&quot;, port&#x3D;32000, ssm_ip&#x3D;\&quot;10.131.159.25\&quot;)) | [optional] 

### Return type

**list[object]**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_pull_look_data**
> list[object] get_pull_look_data(slot_id, look_id)

Retrieves all of the data for a look ID, as defined via the Insights Portal UI

SDK: `get_pull_look_data()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.QualityApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
look_id = 56 # int | Look ID corresponding to an existing look

try:
    # Retrieves all of the data for a look ID, as defined via the Insights Portal UI
    api_response = api_instance.get_pull_look_data(slot_id, look_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling QualityApi->get_pull_look_data: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **look_id** | **int**| Look ID corresponding to an existing look | 

### Return type

**list[object]**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_quality_metrics**
> object get_quality_metrics(slot_id, fields, start_time, end_time, av_reference=av_reference, av_test=av_test)

Retrieves SSIMWAVE quality metrics for a service that has this DUT's service name, for a specific time window

SDK: `get_quality_metrics()`  Notes:  * All A/V Sync metrics only exist once an av_probe is configured using the 'configure_av_probe' endpoint.  * Separate calls to this endpoint are required for various A/V comparisons.  * Audio and video are considered out-of-sync by humans when audio is ahead of/behind video by: -125ms/+45ms.  * Lip-sync problems are considered noticeable at around +/-22ms    (see https://en.wikipedia.org/wiki/Audio-to-video_synchronization#Recommendations).

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.QualityApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
fields = 'fields_example' # str | List of the various quality metric fields that are to be retrieved for this device.                      Each field specified will be included into the response data, if available. SSIMWAVE                      aggregates data into one minute samples and so most metrics have min/max/avg.                      Fields can include:                      - 'avg_qod_score'                 : Average Quality-of-Delivery score                      - 'max_qod_score'                 : Maximum Quality-of-Delivery score                      - 'min_qod_score'                 : Minimum Quality-of-Delivery score                      - 'ssimplus_viewer_score'         : SSIMPLUS subject viewer score calculated                                                          (non-referential ML-based score)                      - 'avg_ssimplus_viewer_score'     : Average SSIMPLUS viewer score calculated                      - 'min_ssimplus_viewer_score'     : Minimum SSIMPLUS viewer score calculated                      - 'avg_short_term_loudness_energy': Average audio levels                      - 'max_true_peak'                 : Maximum audio level                      - 'min_true_peak'                 : Minimum audio level                      - 'sum_macroblocking_frame_count' : Total number of frames in which macroblocking was                                                          detected                      - 'max_macro_blocking_frame_count': Maximum number of frames within each of the 60                                                          one-second samples in which macroblocking was detected                      - 'percent_macroblocking'         : Percentage of frames in which macroblocking was                                                          detected                      - 'min_video_latency'             : Minimum time difference between when a sequence                                                          of video frames was seen at `av_reference` vs.                                                          when it was seen at `av_test`                      - 'max_video_latency'             : Maximum time difference between when a sequence                                                          of video frames was seen at `av_reference` vs.                                                          when it was seen at `av_test`                      - 'avg_video_latency'             : Average time difference between when a sequence                                                          of video frames was seen at `av_reference` vs.                                                          when it was seen at `av_test`                      - 'min_audio_latency'             : Minimum time difference between when a sequence                                                          of audio frames was heard at `av_reference` vs.                                                          when it was seen at `av_test`                      - 'max_audio_latency'             : Minimum time difference between when a sequence                                                          audio frames was heard at `av_reference` vs.                                                          when it was seen at `av_test`                      - 'avg_audio_latency'             : Minimum time difference between when a sequence                                                          audio frames was heard at `av_reference` vs.                                                          when it was seen at `av_test`                      - 'min_audio_offset'              : Minimum difference between video latency and audio                                                          latency                      - 'max_audio_offset'              : Maximum difference between video latency and audio                                                          latency                      - 'is_aligned'                    : \"SSIMWAVE regards the two sources as mutually aligned.\"                                                          (Yes/No string)
start_time = 'start_time_example' # str | Start time for the time window from which to gather data in UTC, specifiable in ISO8601                      or human-readable formats                      (e.g. '2021-06-10T22:56:58.333920', '2021-06-10 22:56:58', '2021-06-10T22:56:58 UTC')
end_time = 'end_time_example' # str | End time for the time window from which to gather data in UTC, specifiable in ISO8601                      or human-readable formats                      (e.g. '2021-06-10T22:56:58.333920', '2021-06-10 22:56:58', '2021-06-10T22:56:58 UTC')
av_reference = 'av_reference_example' # str | Stream considered as the source of truth for A/V sync calculations;                      The stream name is what is returned when configuring a probe (optional)
av_test = 'av_test_example' # str | Stream considered as the thing to compare for A/V sync calculations.                      The stream name is what is returned when configuring a probe (optional)

try:
    # Retrieves SSIMWAVE quality metrics for a service that has this DUT's service name, for a specific time window
    api_response = api_instance.get_quality_metrics(slot_id, fields, start_time, end_time, av_reference=av_reference, av_test=av_test)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling QualityApi->get_quality_metrics: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **fields** | **str**| List of the various quality metric fields that are to be retrieved for this device.                      Each field specified will be included into the response data, if available. SSIMWAVE                      aggregates data into one minute samples and so most metrics have min/max/avg.                      Fields can include:                      - &#x27;avg_qod_score&#x27;                 : Average Quality-of-Delivery score                      - &#x27;max_qod_score&#x27;                 : Maximum Quality-of-Delivery score                      - &#x27;min_qod_score&#x27;                 : Minimum Quality-of-Delivery score                      - &#x27;ssimplus_viewer_score&#x27;         : SSIMPLUS subject viewer score calculated                                                          (non-referential ML-based score)                      - &#x27;avg_ssimplus_viewer_score&#x27;     : Average SSIMPLUS viewer score calculated                      - &#x27;min_ssimplus_viewer_score&#x27;     : Minimum SSIMPLUS viewer score calculated                      - &#x27;avg_short_term_loudness_energy&#x27;: Average audio levels                      - &#x27;max_true_peak&#x27;                 : Maximum audio level                      - &#x27;min_true_peak&#x27;                 : Minimum audio level                      - &#x27;sum_macroblocking_frame_count&#x27; : Total number of frames in which macroblocking was                                                          detected                      - &#x27;max_macro_blocking_frame_count&#x27;: Maximum number of frames within each of the 60                                                          one-second samples in which macroblocking was detected                      - &#x27;percent_macroblocking&#x27;         : Percentage of frames in which macroblocking was                                                          detected                      - &#x27;min_video_latency&#x27;             : Minimum time difference between when a sequence                                                          of video frames was seen at &#x60;av_reference&#x60; vs.                                                          when it was seen at &#x60;av_test&#x60;                      - &#x27;max_video_latency&#x27;             : Maximum time difference between when a sequence                                                          of video frames was seen at &#x60;av_reference&#x60; vs.                                                          when it was seen at &#x60;av_test&#x60;                      - &#x27;avg_video_latency&#x27;             : Average time difference between when a sequence                                                          of video frames was seen at &#x60;av_reference&#x60; vs.                                                          when it was seen at &#x60;av_test&#x60;                      - &#x27;min_audio_latency&#x27;             : Minimum time difference between when a sequence                                                          of audio frames was heard at &#x60;av_reference&#x60; vs.                                                          when it was seen at &#x60;av_test&#x60;                      - &#x27;max_audio_latency&#x27;             : Minimum time difference between when a sequence                                                          audio frames was heard at &#x60;av_reference&#x60; vs.                                                          when it was seen at &#x60;av_test&#x60;                      - &#x27;avg_audio_latency&#x27;             : Minimum time difference between when a sequence                                                          audio frames was heard at &#x60;av_reference&#x60; vs.                                                          when it was seen at &#x60;av_test&#x60;                      - &#x27;min_audio_offset&#x27;              : Minimum difference between video latency and audio                                                          latency                      - &#x27;max_audio_offset&#x27;              : Maximum difference between video latency and audio                                                          latency                      - &#x27;is_aligned&#x27;                    : \&quot;SSIMWAVE regards the two sources as mutually aligned.\&quot;                                                          (Yes/No string) | 
 **start_time** | **str**| Start time for the time window from which to gather data in UTC, specifiable in ISO8601                      or human-readable formats                      (e.g. &#x27;2021-06-10T22:56:58.333920&#x27;, &#x27;2021-06-10 22:56:58&#x27;, &#x27;2021-06-10T22:56:58 UTC&#x27;) | 
 **end_time** | **str**| End time for the time window from which to gather data in UTC, specifiable in ISO8601                      or human-readable formats                      (e.g. &#x27;2021-06-10T22:56:58.333920&#x27;, &#x27;2021-06-10 22:56:58&#x27;, &#x27;2021-06-10T22:56:58 UTC&#x27;) | 
 **av_reference** | **str**| Stream considered as the source of truth for A/V sync calculations;                      The stream name is what is returned when configuring a probe | [optional] 
 **av_test** | **str**| Stream considered as the thing to compare for A/V sync calculations.                      The stream name is what is returned when configuring a probe | [optional] 

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_signal_metrics**
> object get_signal_metrics(slot_id)

Retrieves all audio/video signal quality metrics recorded by SSIMWAVE for this DUT

SDK: `get_signal_metrics()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.QualityApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Retrieves all audio/video signal quality metrics recorded by SSIMWAVE for this DUT
    api_response = api_instance.get_signal_metrics(slot_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling QualityApi->get_signal_metrics: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

