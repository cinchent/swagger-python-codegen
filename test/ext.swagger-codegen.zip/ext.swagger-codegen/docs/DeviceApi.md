# sdk.DeviceApi

All URIs are relative to */api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**do_enter_text**](DeviceApi.md#do_enter_text) | **POST** /device/enter_text/{slot_id} | Enters text into the current UI input element, if applicable, optionally followed by pressing the ENTER key         (button)
[**do_exit_device**](DeviceApi.md#do_exit_device) | **POST** /device/exit/{slot_id} | Performs any device-specific termination or closure to cede usage of the player device
[**do_file_download**](DeviceApi.md#do_file_download) | **POST** /device/file_download/{slot_id} | Downloads a file from the local BATS Server filesystem to a specified destination on the player device
[**do_file_upload**](DeviceApi.md#do_file_upload) | **POST** /device/file_upload/{slot_id} | Uploads a file from the player device to a specified destination on the local BATS Server filesystem
[**do_firmware_install**](DeviceApi.md#do_firmware_install) | **POST** /device/firmware_install/{slot_id} | Installs specified firmware version on the player device
[**do_identify_make_model_variant**](DeviceApi.md#do_identify_make_model_variant) | **POST** /device/identify_make_model_variant/{slot_id} | Interacts with the player device to infer its specific make/model/variant, and verify that it identifies         itself as expected
[**do_init_device**](DeviceApi.md#do_init_device) | **POST** /device/init/{slot_id} | Performs any device-specific on-device initialization to restore the player device to a known canonical state         in preparation for its use in an auditing/testing scenario
[**do_navigate**](DeviceApi.md#do_navigate) | **POST** /device/navigate/{slot_id} | Navigates directly to a specified \&quot;bookmark\&quot; in the device user interface
[**do_play_asset**](DeviceApi.md#do_play_asset) | **POST** /device/play_asset/{slot_id} | Initiates playback of the asset currently selected
[**do_press_key**](DeviceApi.md#do_press_key) | **POST** /device/press_key/{slot_id} | Enters a \&quot;keypress\&quot; into the device UI using whatever control plane is provided for the player device
[**do_reboot_device**](DeviceApi.md#do_reboot_device) | **POST** /device/reboot/{slot_id} | Interacts with this player device to cause it to reboot itself
[**do_seek**](DeviceApi.md#do_seek) | **POST** /device/seek/{slot_id} | Moves playback position chronologically to a fixed time in the stream
[**do_shutdown**](DeviceApi.md#do_shutdown) | **POST** /device/shutdown/{slot_id} | Ceases active stream processing for this device and terminates its worker process
[**do_startup**](DeviceApi.md#do_startup) | **POST** /device/startup/{slot_id} | Spawns the worker process for this device and starts active stream processing
[**do_tune**](DeviceApi.md#do_tune) | **POST** /device/tune/{slot_id} | Changes content source for video/audio stream being played on main screen of device
[**do_watch_playback**](DeviceApi.md#do_watch_playback) | **POST** /device/watch_playback/{slot_id} | Navigates to active TV watching of the video/audio stream
[**get_channel_map**](DeviceApi.md#get_channel_map) | **GET** /device/channel_map/{slot_id} | Retrieves provider channel map for account by which device is authorized
[**get_device_code_version**](DeviceApi.md#get_device_code_version) | **GET** /device/device_code_version/{slot_id} | Retrieves the version(s) for all applicable code/firmware currently loaded on this player device
[**get_device_details**](DeviceApi.md#get_device_details) | **GET** /device/device_details/{slot_id} | Retrieves and returns device-specific information, some of which may be queried from external services
[**get_logs**](DeviceApi.md#get_logs) | **GET** /device/collect_logs/{slot_id} | Retrieves a device category-specific collection of logs from the player device, stores them on the server         filesystem, and optionally retrieves their content as a BLOB
[**get_screenshot**](DeviceApi.md#get_screenshot) | **GET** /device/screenshot/{slot_id} | Captures and returns a snapshot of the current screen frame from the player device control plane
[**get_setting**](DeviceApi.md#get_setting) | **GET** /device/setting/{slot_id} | Returns a particular setting value from this player device
[**set_asset**](DeviceApi.md#set_asset) | **POST** /device/set_asset/{slot_id} | Specifies the current streaming asset to use for auditing and testing purposes
[**set_controls_mode**](DeviceApi.md#set_controls_mode) | **POST** /device/set_controls_mode/{slot_id} | Reveals/hides onscreen \&quot;remote\&quot; controls
[**set_setting**](DeviceApi.md#set_setting) | **POST** /device/setting/{slot_id} | Modifies a particular setting on this player device

# **do_enter_text**
> bool do_enter_text(slot_id, text, numeric=numeric, enter=enter, press_delay=press_delay, enter_delay=enter_delay)

Enters text into the current UI input element, if applicable, optionally followed by pressing the ENTER key         (button)

SDK: `do_enter_text()`  Notes: <br>... [STB]  * Only numeric text entry is supported at this time.  * If applicable, uses the IR blaster channel dedicated to this device to enter the sequence of numeric digits    using its remote control.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
text = 'text_example' # str | Text to enter (when numeric, specify as a string for leading zeroes)
numeric = false # bool | \"`text` must be numeric.\" (optional) (default to false)
enter = false # bool | \"Press ENTER (a.k.a. OK) button after entering text.\" (optional) (default to false)
press_delay = 0.8 # float | [STB] Pacing duration (sec) to delay between pressing buttons (optional) (default to 0.8)
enter_delay = 2.0 # float | [STB] Pacing duration (sec) to delay after pressing all buttons (optional) (default to 2.0)

try:
    # Enters text into the current UI input element, if applicable, optionally followed by pressing the ENTER key         (button)
    api_response = api_instance.do_enter_text(slot_id, text, numeric=numeric, enter=enter, press_delay=press_delay, enter_delay=enter_delay)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeviceApi->do_enter_text: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **text** | **str**| Text to enter (when numeric, specify as a string for leading zeroes) |
 **numeric** | **bool**| \&quot;&#x60;text&#x60; must be numeric.\&quot; | [optional] [default to false]
 **enter** | **bool**| \&quot;Press ENTER (a.k.a. OK) button after entering text.\&quot; | [optional] [default to false]
 **press_delay** | **float**| [STB] Pacing duration (sec) to delay between pressing buttons | [optional] [default to 0.8]
 **enter_delay** | **float**| [STB] Pacing duration (sec) to delay after pressing all buttons | [optional] [default to 2.0]

### Return type

**bool**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_exit_device**
> do_exit_device(slot_id)

Performs any device-specific termination or closure to cede usage of the player device

SDK: `do_exit_device()`  Notes:  * If there is a resource request in progress on the player device, the `exit` resource will cause that    outstanding request to become terminated immediately and its HTTP status returned as 410 GONE.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Performs any device-specific termination or closure to cede usage of the player device
    api_instance.do_exit_device(slot_id)
except ApiException as e:
    print("Exception when calling DeviceApi->do_exit_device: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_file_download**
> do_file_download(slot_id, local_filespec, device_filespec, timeout=timeout, overwrite=overwrite, verify=verify)

Downloads a file from the local BATS Server filesystem to a specified destination on the player device

SDK: `do_file_download()`  :raises: PlayerParameterError if local file is inaccessible :raises: PlayerDeviceError if download to STB fails  Notes:  * CAUTION: Specifying None for `timeout` can hang this request execution perpetually.  <br>... [STB]  * For a multi-stage file transfer (through a Jump Server), the timeout applies to each stage, per retry.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
local_filespec = 'local_filespec_example' # str | File specification for source file on the local filesystem (representable as a str)
device_filespec = 'device_filespec_example' # str | File specification for destination file on the STB
timeout = 1.2 # float | Timeout period (sec) allowed for file transfer (None => unlimited duration) (optional)
overwrite = true # bool | [STB] \"Overwrites destination file on STB if it already exists.\" (otherwise fails) (optional) (default to true)
verify = false # bool | \"Requires file content verification to succeed.\"                   (otherwise verifies content, but does not fail on mismatch) (optional) (default to false)

try:
    # Downloads a file from the local BATS Server filesystem to a specified destination on the player device
    api_instance.do_file_download(slot_id, local_filespec, device_filespec, timeout=timeout, overwrite=overwrite, verify=verify)
except ApiException as e:
    print("Exception when calling DeviceApi->do_file_download: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **local_filespec** | **str**| File specification for source file on the local filesystem (representable as a str) |
 **device_filespec** | **str**| File specification for destination file on the STB |
 **timeout** | **float**| Timeout period (sec) allowed for file transfer (None &#x3D;&gt; unlimited duration) | [optional]
 **overwrite** | **bool**| [STB] \&quot;Overwrites destination file on STB if it already exists.\&quot; (otherwise fails) | [optional] [default to true]
 **verify** | **bool**| \&quot;Requires file content verification to succeed.\&quot;                   (otherwise verifies content, but does not fail on mismatch) | [optional] [default to false]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_file_upload**
> do_file_upload(slot_id, device_filespec, local_filespec, timeout=timeout, overwrite=overwrite, verify=verify)

Uploads a file from the player device to a specified destination on the local BATS Server filesystem

SDK: `do_file_upload()`  :raises: PlayerParameterError if local file is inaccessible :raises: PlayerDeviceError if upload from STB fails  Notes:  * CAUTION: Specifying None for `timeout` can hang this request execution perpetually.  <br>... [STB]  * For a multi-stage file transfer (through a Jump Server), the timeout applies to each stage, per retry.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
device_filespec = 'device_filespec_example' # str | File specification for source file on the STB
local_filespec = 'local_filespec_example' # str | File specification for destination file on the local filesystem (representable as a str)
timeout = 1.2 # float | Timeout period (sec) allowed for file transfer (None => unlimited duration) (optional)
overwrite = true # bool | \"Allow overwrite of local file.\" (optional) (default to true)
verify = false # bool | \"Requires file content verification to succeed.\"                   (otherwise verifies content, but does not fail on mismatch) (optional) (default to false)

try:
    # Uploads a file from the player device to a specified destination on the local BATS Server filesystem
    api_instance.do_file_upload(slot_id, device_filespec, local_filespec, timeout=timeout, overwrite=overwrite, verify=verify)
except ApiException as e:
    print("Exception when calling DeviceApi->do_file_upload: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **device_filespec** | **str**| File specification for source file on the STB |
 **local_filespec** | **str**| File specification for destination file on the local filesystem (representable as a str) |
 **timeout** | **float**| Timeout period (sec) allowed for file transfer (None &#x3D;&gt; unlimited duration) | [optional]
 **overwrite** | **bool**| \&quot;Allow overwrite of local file.\&quot; | [optional] [default to true]
 **verify** | **bool**| \&quot;Requires file content verification to succeed.\&quot;                   (otherwise verifies content, but does not fail on mismatch) | [optional] [default to false]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_firmware_install**
> list[object] do_firmware_install(slot_id, image_file, image_dir=image_dir, force=force, ignore_mismatch=ignore_mismatch, timeout=timeout)

Installs specified firmware version on the player device

SDK: `do_firmware_install()`  :raises: ServiceNetworkError if needed network infrastructure or resource is unavailable                              (e.g., RDK Portal, CDL Server, firmware image, etc.) :raises: PlayerParameterError if a download parameter is misspecified :raises: PlayerDeviceError if a necessary attribute is incorrect or an internal processing error occurred  Notes:  * Specified timeout is approximate; download procedure may take longer than this timeout due to ancillary    command execution.  <br>... [STB]  * RDK firmware image is installed using the whatever installation method is defined for the STB device type.  * When no `image_dir` is specified, the RDK image is downloaded directly by the device from the XXXXXXX    Code DownLoad (CDL) server.  The CDL server only caches a subset of images available from the RDK Portal;    acquire the desired image RDK Portal manually and specify an explicit `image_dir` if retrieval of the image    from the CDL server fails.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
image_file = 'image_file_example' # str | Name of firmware image file to install
image_dir = 'image_dir_example' # str | Local directory where image file resides (None => download image file from code server) (optional)
force = false # bool | \"Install firmware even if it appears that device has the same version installed.\" (optional) (default to false)
ignore_mismatch = false # bool | \"Install firmware even if its filename prefix mismatches this device make/model.\" (optional) (default to false)
timeout = 600.0 # float | Timeout period (sec) allowed for entire download/installation procedure                         (None => unlimited duration) (optional) (default to 600.0)

try:
    # Installs specified firmware version on the player device
    api_response = api_instance.do_firmware_install(slot_id, image_file, image_dir=image_dir, force=force, ignore_mismatch=ignore_mismatch, timeout=timeout)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeviceApi->do_firmware_install: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **image_file** | **str**| Name of firmware image file to install |
 **image_dir** | **str**| Local directory where image file resides (None &#x3D;&gt; download image file from code server) | [optional]
 **force** | **bool**| \&quot;Install firmware even if it appears that device has the same version installed.\&quot; | [optional] [default to false]
 **ignore_mismatch** | **bool**| \&quot;Install firmware even if its filename prefix mismatches this device make/model.\&quot; | [optional] [default to false]
 **timeout** | **float**| Timeout period (sec) allowed for entire download/installation procedure                         (None &#x3D;&gt; unlimited duration) | [optional] [default to 600.0]

### Return type

**list[object]**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_identify_make_model_variant**
> str do_identify_make_model_variant(slot_id)

Interacts with the player device to infer its specific make/model/variant, and verify that it identifies         itself as expected

SDK: `do_identify_make_model_variant()`  Notes: <br>... [STB]  * Uses the STB shell prompt to verify the actual make/model/variant.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Interacts with the player device to infer its specific make/model/variant, and verify that it identifies         itself as expected
    api_response = api_instance.do_identify_make_model_variant(slot_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeviceApi->do_identify_make_model_variant: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_init_device**
> DeviceDefinition do_init_device(slot_id, strict=strict, reboot=reboot, restart_receiver=restart_receiver, force_playback=force_playback, no_shell=no_shell, use_xapi=use_xapi, no_cache=no_cache, ssp_player_app=ssp_player_app, ssp_player_build=ssp_player_build, capabilities=capabilities)

Performs any device-specific on-device initialization to restore the player device to a known canonical state         in preparation for its use in an auditing/testing scenario

SDK: `do_init_device()`  Notes: <br>... [STB]   * Optionally establishes and activates the communications interface with the STB device, initializes the XAPI     client, and performs any on-device initialization to initialize or restore the STB to a generic state.   * If an alternate XAPI is specified, it may also require an alternate associated XRE to be specified as an     override in the STB receiver configuration file; doing this is not the responsibility of the EAPI.  <br>... [SSP]  * Establishes and activates a session with the SSPC device driver, logs in to the SSP device via the driver,    and performs any on-device initialization to initialize or restore the SSP to a generic state.  * `capabilities` includes all options for SSPC and the applications it manages, and may be specified in one    of these ways:     - as JSON, or     - as a newline- or ','-delimited sequence of key=value pairs, or     - as a '@'-prefixed file specification for a file containing either of the above

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
strict = false # bool | \"Only permit initialization of device if it is fully quiescent (not already initialized).\" (optional) (default to false)
reboot = false # bool | [STB] \"Perform a warm reboot of the entire device first.\" (optional) (default to false)
restart_receiver = false # bool | [STB] \"Perform a reset of the STB receiver component first.\" (ignored if `reboot` specified) (optional) (default to false)
force_playback = true # bool | [STB] \"Take action to emerge from Idle or clear dialog, back to active content playback.\" (optional) (default to true)
no_shell = false # bool | [STB] \"Circumvent establishing shell session (debug only).\" (optional) (default to false)
use_xapi = 'True' # str | XAPI variant to use:                             False => no XAPI usage (debug only)                             True => default (normal) production XAPI, as configured                             or one of: {'prod', 'ci', 'eas'}                             (may also be full base URL for XAPI service) (optional) (default to True)
no_cache = false # bool | [STB] \"Ignore cached dynamic device info and explicitly retrieve afresh from xSearch API.\" (optional) (default to false)
ssp_player_app = 'XS' # str | Embedded SSP application/stack doing player control ('PP' or 'XS'):                          PP: VIPER Player Platform @@@@ Deprecated                          XS: Xfinity Stream app (optional) (default to XS)
ssp_player_build = 'prod' # str | [SSP] Build for SSP player app/stack, if applicable ('dev' or 'prod') (optional) (default to prod)
capabilities = 'capabilities_example' # str | Overrides for SSP device capabilities                          (unspecified => use configured/default capabilities) (optional)

try:
    # Performs any device-specific on-device initialization to restore the player device to a known canonical state         in preparation for its use in an auditing/testing scenario
    api_response = api_instance.do_init_device(slot_id, strict=strict, reboot=reboot, restart_receiver=restart_receiver, force_playback=force_playback, no_shell=no_shell, use_xapi=use_xapi, no_cache=no_cache, ssp_player_app=ssp_player_app, ssp_player_build=ssp_player_build, capabilities=capabilities)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeviceApi->do_init_device: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **strict** | **bool**| \&quot;Only permit initialization of device if it is fully quiescent (not already initialized).\&quot; | [optional] [default to false]
 **reboot** | **bool**| [STB] \&quot;Perform a warm reboot of the entire device first.\&quot; | [optional] [default to false]
 **restart_receiver** | **bool**| [STB] \&quot;Perform a reset of the STB receiver component first.\&quot; (ignored if &#x60;reboot&#x60; specified) | [optional] [default to false]
 **force_playback** | **bool**| [STB] \&quot;Take action to emerge from Idle or clear dialog, back to active content playback.\&quot; | [optional] [default to true]
 **no_shell** | **bool**| [STB] \&quot;Circumvent establishing shell session (debug only).\&quot; | [optional] [default to false]
 **use_xapi** | **str**| XAPI variant to use:                             False &#x3D;&gt; no XAPI usage (debug only)                             True &#x3D;&gt; default (normal) production XAPI, as configured                             or one of: {&#x27;prod&#x27;, &#x27;ci&#x27;, &#x27;eas&#x27;}                             (may also be full base URL for XAPI service) | [optional] [default to True]
 **no_cache** | **bool**| [STB] \&quot;Ignore cached dynamic device info and explicitly retrieve afresh from xSearch API.\&quot; | [optional] [default to false]
 **ssp_player_app** | **str**| Embedded SSP application/stack doing player control (&#x27;PP&#x27; or &#x27;XS&#x27;):                          PP: VIPER Player Platform @@@@ Deprecated                          XS: Xfinity Stream app | [optional] [default to XS]
 **ssp_player_build** | **str**| [SSP] Build for SSP player app/stack, if applicable (&#x27;dev&#x27; or &#x27;prod&#x27;) | [optional] [default to prod]
 **capabilities** | **str**| Overrides for SSP device capabilities                          (unspecified &#x3D;&gt; use configured/default capabilities) | [optional]

### Return type

[**DeviceDefinition**](DeviceDefinition.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_navigate**
> str do_navigate(slot_id, bookmark, retry=retry)

Navigates directly to a specified \"bookmark\" in the device user interface

SDK: `do_navigate()`  Notes: <br>... [STB]  * For specific information about supported `bookmark` and `params` values supported by XAPI, see    https://etwiki.sys.XXXXXXX.net/pages/viewpage.action?spaceKey=xcalPDEV&title=XAPI+Service++Specification    (section 3.7.1 \"navigateto\").  <br>... [SSP]  * The following `params` items are recognized for generic navigation:      type:     (str) Navigation type: 'ID' or 'XPATH' (case-insensitive, default: ID)      constant: (bool) \"Look up navigation `bookmark` within SSPC platform-specific constants.\" (else verbatim)                       (default: True)      click:    (bool) \"Automatically 'click' the navigated item.\" (else just select destination)                       (default: True)

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
bookmark = 'bookmark_example' # str | Page identifier/location (a.k.a. \"bookmark\") to navigate to
retry = true # bool | [STB] \"Press EXIT and retry navigation on failure.\" (optional) (default to true)

try:
    # Navigates directly to a specified \"bookmark\" in the device user interface
    api_response = api_instance.do_navigate(slot_id, bookmark, retry=retry)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeviceApi->do_navigate: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **bookmark** | **str**| Page identifier/location (a.k.a. \&quot;bookmark\&quot;) to navigate to |
 **retry** | **bool**| [STB] \&quot;Press EXIT and retry navigation on failure.\&quot; | [optional] [default to true]

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_play_asset**
> bool do_play_asset(slot_id, resume=resume, network=network)

Initiates playback of the asset currently selected

SDK: `do_play_asset()`  Notes:  * If an asset has not been previously specified by `set_asset()`, begins/resumes playback of the current    streaming source in effect for the player, if any.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
resume = false # bool | \"Resume playback of previously stopped asset, if applicable.\" (else start playback anew) (optional) (default to false)
network = 'network_example' # str | Network from which playback of asset should originate (e.g., VOD_TVGO)                 (None => default network) (optional)

try:
    # Initiates playback of the asset currently selected
    api_response = api_instance.do_play_asset(slot_id, resume=resume, network=network)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeviceApi->do_play_asset: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **resume** | **bool**| \&quot;Resume playback of previously stopped asset, if applicable.\&quot; (else start playback anew) | [optional] [default to false]
 **network** | **str**| Network from which playback of asset should originate (e.g., VOD_TVGO)                 (None &#x3D;&gt; default network) | [optional]

### Return type

**bool**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_press_key**
> bool do_press_key(slot_id, button, repeat=repeat, delay=delay)

Enters a \"keypress\" into the device UI using whatever control plane is provided for the player device

SDK: `do_press_key()`  Notes: <br>... [STB]  * Uses the XAPI to simulate remote control keypresses via XRE/Linchpin; if available as a device option    and if hardware is configured to do so.  * When using XAPI, the success/fail return value indicates positive feedback from XAPI that the keypress    was successfully sent to the STB.  <br>... [SSP]  * Uses the SSPC driver layer to simulate player control application UI touches/clicks via Appium/Selenium.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
button = 'button_example' # str | Button (key) to press on the \"remote control\" (must be one of known BUTTON definitions)
repeat = 1 # int | Repeat count for button press (number of consecutive presses) (optional) (default to 1)
delay = 2.0 # float | Pacing duration (sec) to delay after each button press (optional) (default to 2.0)

try:
    # Enters a \"keypress\" into the device UI using whatever control plane is provided for the player device
    api_response = api_instance.do_press_key(slot_id, button, repeat=repeat, delay=delay)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeviceApi->do_press_key: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **button** | **str**| Button (key) to press on the \&quot;remote control\&quot; (must be one of known BUTTON definitions) |
 **repeat** | **int**| Repeat count for button press (number of consecutive presses) | [optional] [default to 1]
 **delay** | **float**| Pacing duration (sec) to delay after each button press | [optional] [default to 2.0]

### Return type

**bool**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_reboot_device**
> bool do_reboot_device(slot_id, timeout=timeout, use_shell=use_shell)

Interacts with this player device to cause it to reboot itself

SDK: `do_reboot_device()`  Notes:  * Executes synchronously, not returning until device is (presumably) rebooted.  <br>... [STB]  * This is not a reliable indicator that the device is reachable via the Jump Server or that the XRE has been    connected (if applicable): success does not necessarily mean that the device has connected to the XRE, but    typically if the device can be logged into via SSH, then the device can connect to the XRE.  * When XAPI rebooting is selected, uses the XAPI `check_alive` endpoint to verify the device is back up.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
timeout = 1200.0 # float | Timeout period (sec), within which reboot is expected to complete (optional) (default to 1200.0)
use_shell = true # bool | \"Use shell connection to reboot the device and verify is back up and running.\"                   (else use XAPI) (optional) (default to true)

try:
    # Interacts with this player device to cause it to reboot itself
    api_response = api_instance.do_reboot_device(slot_id, timeout=timeout, use_shell=use_shell)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeviceApi->do_reboot_device: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **timeout** | **float**| Timeout period (sec), within which reboot is expected to complete | [optional] [default to 1200.0]
 **use_shell** | **bool**| \&quot;Use shell connection to reboot the device and verify is back up and running.\&quot;                   (else use XAPI) | [optional] [default to true]

### Return type

**bool**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_seek**
> do_seek(slot_id, time_offset)

Moves playback position chronologically to a fixed time in the stream

SDK: `do_seek()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
time_offset = 1.2 # float | Time offset (sec) from start within asset where to continue playback

try:
    # Moves playback position chronologically to a fixed time in the stream
    api_instance.do_seek(slot_id, time_offset)
except ApiException as e:
    print("Exception when calling DeviceApi->do_seek: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **time_offset** | **float**| Time offset (sec) from start within asset where to continue playback |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_shutdown**
> do_shutdown(slot_id, kill=kill)

Ceases active stream processing for this device and terminates its worker process

SDK: `do_shutdown()`  Notes:  * Halts processing operations for the device within the BATS processing abstraction object corresponding    to the player device in the BATS Core library, and destroys that object.  * WARNING: this will typically not return!

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
kill = false # bool | \"Kill BATS Core media stream engine explicitly after calling its shutdown() method.\" (optional) (default to false)

try:
    # Ceases active stream processing for this device and terminates its worker process
    api_instance.do_shutdown(slot_id, kill=kill)
except ApiException as e:
    print("Exception when calling DeviceApi->do_shutdown: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **kill** | **bool**| \&quot;Kill BATS Core media stream engine explicitly after calling its shutdown() method.\&quot; | [optional] [default to false]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_startup**
> do_startup(slot_id, force=force, origin=origin, audio=audio, repeat=repeat, speed=speed)

Spawns the worker process for this device and starts active stream processing

SDK: `do_startup()`  Notes:  * The BATS processing abstraction object corresponding to the player device in the BATS Core library    is instantiated from the worker process, and processing operations for the device within that abstraction    are initiated.  * WARNING! Once instantiated, all use of/interaction with the BATS Core object must occur within the    worker process.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
force = false # bool | \"Forcibly kill existing worker process and spawn a new worker if it was not already shut down.\" (optional) (default to false)
origin = 'N/A' # str | Origin for BATS Core stream source -- choices: [] (optional) (default to N/A)
audio = true # bool | \"Also include audio in stream processing.\" (optional) (default to true)
repeat = false # bool | (heeded for URL streams only) \"Repeat media streaming in continuous loop.\" (optional) (default to false)
speed = -1.0 # float | (heeded for URL streams only) Speed multiplier for playback (- => as fast as possible) (optional) (default to -1.0)

try:
    # Spawns the worker process for this device and starts active stream processing
    api_instance.do_startup(slot_id, force=force, origin=origin, audio=audio, repeat=repeat, speed=speed)
except ApiException as e:
    print("Exception when calling DeviceApi->do_startup: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **force** | **bool**| \&quot;Forcibly kill existing worker process and spawn a new worker if it was not already shut down.\&quot; | [optional] [default to false]
 **origin** | **str**| Origin for BATS Core stream source -- choices: [] | [optional] [default to N/A]
 **audio** | **bool**| \&quot;Also include audio in stream processing.\&quot; | [optional] [default to true]
 **repeat** | **bool**| (heeded for URL streams only) \&quot;Repeat media streaming in continuous loop.\&quot; | [optional] [default to false]
 **speed** | **float**| (heeded for URL streams only) Speed multiplier for playback (- &#x3D;&gt; as fast as possible) | [optional] [default to -1.0]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_tune**
> str do_tune(slot_id, source_type, source, retune=retune, wait=wait)

Changes content source for video/audio stream being played on main screen of device

SDK: `do_tune()`  Notes: <br>... [STB]  * `source_type` is limited to any one of those supported by XAPI/deeplinks (see `source` below)  * `source` depends upon `source_type`; these sources are recognized:       channel:  (int) linear channel number (-1 => most recent channel visited previously)       callsign: (str) linear channel callsign       VOD:      (str) URL for VOD (format: vod://<providerId><contentId>)       DVR:      (str) URL for DVR resource (recording ID)       web:      (str) arbitrary web URL  <br>... [SSP]  * `source_type` and `source` depends upon the asset source from which the current asset is selected;    for the purposes of specifying these tuning parameters, see STB conventions.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
source_type = 'source_type_example' # str | Source type for stream content
source = 'source_example' # str | Specific source for content of `source_type`
retune = true # bool | [STB] \"(linear only) Perform retuning operation (to IP) in case already tuned to `source`.\" (else skip) (optional) (default to true)
wait = true # bool | [STB] \"Wait for/validate response from tuning operation.\" (optional) (default to true)

try:
    # Changes content source for video/audio stream being played on main screen of device
    api_response = api_instance.do_tune(slot_id, source_type, source, retune=retune, wait=wait)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeviceApi->do_tune: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **source_type** | **str**| Source type for stream content |
 **source** | **str**| Specific source for content of &#x60;source_type&#x60; |
 **retune** | **bool**| [STB] \&quot;(linear only) Perform retuning operation (to IP) in case already tuned to &#x60;source&#x60;.\&quot; (else skip) | [optional] [default to true]
 **wait** | **bool**| [STB] \&quot;Wait for/validate response from tuning operation.\&quot; | [optional] [default to true]

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_watch_playback**
> do_watch_playback(slot_id, fullscreen=fullscreen)

Navigates to active TV watching of the video/audio stream

SDK: `do_watch_playback()`  Notes: <br>... [STB]  * Entering \"fullscreen\" mode on an STB entails immediately exiting from all menus/submenus and/or dialogs.  * Wakes the STB from sleep mode if applicable.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
fullscreen = true # bool | \"Switch viewing to fullscreen mode, if applicable/possible.\" (else to windowed mode) (optional) (default to true)

try:
    # Navigates to active TV watching of the video/audio stream
    api_instance.do_watch_playback(slot_id, fullscreen=fullscreen)
except ApiException as e:
    print("Exception when calling DeviceApi->do_watch_playback: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **fullscreen** | **bool**| \&quot;Switch viewing to fullscreen mode, if applicable/possible.\&quot; (else to windowed mode) | [optional] [default to true]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_channel_map**
> object get_channel_map(slot_id)

Retrieves provider channel map for account by which device is authorized

SDK: `get_channel_map()`  Notes: <br>... [STB]  * Channel map is ordered as extracted from XAPI, probably numerically.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Retrieves provider channel map for account by which device is authorized
    api_response = api_instance.get_channel_map(slot_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeviceApi->get_channel_map: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_device_code_version**
> object get_device_code_version(slot_id)

Retrieves the version(s) for all applicable code/firmware currently loaded on this player device

SDK: `get_device_code_version()`  Notes: <br>... [STB]  * Sole code version retrieved is for the operating RDK firmware.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Retrieves the version(s) for all applicable code/firmware currently loaded on this player device
    api_response = api_instance.get_device_code_version(slot_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeviceApi->get_device_code_version: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_device_details**
> object get_device_details(slot_id)

Retrieves and returns device-specific information, some of which may be queried from external services

SDK: `get_device_details()`  Notes: <br>... [STB]  * For xSearch to return network info for a partner device on the XXXXXXX network, it's necessary to search    via eSTB MAC with partner='XXXXXXX' (not via x1 Device ID).

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Retrieves and returns device-specific information, some of which may be queried from external services
    api_response = api_instance.get_device_details(slot_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeviceApi->get_device_details: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_logs**
> list[object] get_logs(slot_id, filespec=filespec, content=content, timeout=timeout)

Retrieves a device category-specific collection of logs from the player device, stores them on the server         filesystem, and optionally retrieves their content as a BLOB

SDK: `get_logs()`  Notes:  * May be size-limited by HTTP-based transmission interface when retrieving log content; recommended to use    'file_upload' for large files instead.  <br>... [STB]     * `filespec`==None => retrieve canonical set of STB logs as a .tar.gz file  <br>... [SSP]  * `filespec`==None => retrieve canonical set of SSPC Hub logs as a tar.gz file

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
filespec = 'filespec_example' # str | File specification for a file on the player device filesystem where the logs are stored                  (None => retrieve a canonical set of logs specific to the device category) (optional)
content = true # bool | \"Return BLOB containing collected log content.\"                  (else return server filespec where content is stored) (optional) (default to true)
timeout = 1.2 # float | Timeout period (sec) allowed for log retrieval from STB (None => unlimited duration) (optional)

try:
    # Retrieves a device category-specific collection of logs from the player device, stores them on the server         filesystem, and optionally retrieves their content as a BLOB
    api_response = api_instance.get_logs(slot_id, filespec=filespec, content=content, timeout=timeout)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeviceApi->get_logs: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **filespec** | **str**| File specification for a file on the player device filesystem where the logs are stored                  (None &#x3D;&gt; retrieve a canonical set of logs specific to the device category) | [optional]
 **content** | **bool**| \&quot;Return BLOB containing collected log content.\&quot;                  (else return server filespec where content is stored) | [optional] [default to true]
 **timeout** | **float**| Timeout period (sec) allowed for log retrieval from STB (None &#x3D;&gt; unlimited duration) | [optional]

### Return type

**list[object]**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_screenshot**
> str get_screenshot(slot_id, filename=filename, content=content)

Captures and returns a snapshot of the current screen frame from the player device control plane

SDK: `get_screenshot()`  Notes:  * Uses whatever device category-specific facility exists in the control plane for retrieving the frame image.  * Use `analysis_api.get_screenshot()` to capture the image from the stream capture hardware.  * See `capture_screenshot()` for the default file specification.  <br>... [STB]  * Retrieves frame image from the XRE screenshot service.  <br>... [SSP]  * Retrieves frame image from SSPC.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
filename = 'filename_example' # str | File specification where to store current screen frame captured (None => default capture file) (optional)
content = false # bool | \"Return encoded BLOB containing frame content.\"  (else return filespec where content is stored) (optional) (default to false)

try:
    # Captures and returns a snapshot of the current screen frame from the player device control plane
    api_response = api_instance.get_screenshot(slot_id, filename=filename, content=content)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeviceApi->get_screenshot: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **filename** | **str**| File specification where to store current screen frame captured (None &#x3D;&gt; default capture file) | [optional]
 **content** | **bool**| \&quot;Return encoded BLOB containing frame content.\&quot;  (else return filespec where content is stored) | [optional] [default to false]

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_setting**
> object get_setting(slot_id, setting)

Returns a particular setting value from this player device

SDK: `get_setting()`  Notes:  * To reduce the number of external services requests incurred, settings values retrieved by this resource are    cached for future retrievals.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
setting = 'setting_example' # str | Name of player device setting to retrieve (case-insensitive) -- see model `DeviceSettings`                 (not all settings available for all device categories)

try:
    # Returns a particular setting value from this player device
    api_response = api_instance.get_setting(slot_id, setting)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeviceApi->get_setting: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **setting** | **str**| Name of player device setting to retrieve (case-insensitive) -- see model &#x60;DeviceSettings&#x60;                 (not all settings available for all device categories) |

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **set_asset**
> set_asset(slot_id, asset, asset_index=asset_index, asset_selector=asset_selector, override=override, access_check=access_check, override_type=override_type)

Specifies the current streaming asset to use for auditing and testing purposes

SDK: `set_asset()`  Notes:  * An Asset Index is a curated collection of supported streaming assets (e.g., VOD, linear streams,    DVR recordings, etc.) usable for testing/auditing purposes here.  <br>... [STB]  * By default STBs play content streamed from the XXXXXXX production Content Delivery Network (CDN), unless    an asset URL is installed in a special configuration file on the STB which \"overrides\" the streaming source    to be that specified asset.  * Asset URLs can override streaming at either of these injection points:     * AAMP: adds an override def in the AAMP (Advanced Adaptive Media Player) configuration file on the STB     * XRE:  replaces the 'aveOverrideContentURL' field in the XRE configuration file on the STB  * The `override` parameter specifies an asset URL substring pattern, and when an asset containing that    pattern is matched during a \"tuning\" operation, the specified `asset` is tuned to instead.  * If the `asset` specified is itself overridden on the STB, that override is removed first, before establishing     the intended override.  * The STB receiver component is reset as a side-effect in order to effect the asset override.    <br>... [STB]  * Default `asset_index` is \"{DEFAULT_ASSET_INDEX}\".  <br>... [SSP]  * Default `asset_index` is \"{DEFAULT_ASSET_INDEX}\".

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
asset = 'asset_example' # str | URL or other identifier for asset to use (depends upon asset_index)                        (vacuous => remove override for call_sign)
asset_index = 'asset_index_example' # str | Asset Index where asset information is stored (unspecified => use default index) (optional)
asset_selector = 'asset_selector_example' # str | Asset selector -- items heeded:                         * season:           (XS, PP) The number of the season to choose from                         * zip_code:         (PP) Simulated location (VSS) for asset playback                         * performance:      (PP) \"Asset is a performance.\"                         * eas:              (PP) \"EAS enabled.\"                         * asset_type:       (STB, XS) Type of asset (Linear, VOD, etc.)                         * channel_key:      (XS) Choose asset by some \"key\" to look for (example: \"ep9\")                         * channel_collection (XS) Channel collection from which the linear asset is selected                                                 (expects names such as: Showtime, HBO, HLN, CBS, CNN, etc)                         * check_recent:     (XS) Check to see if there is the asset is in the recent list                                                  (expects keywords \"TV\" or \"Movie\" for VOD assets) (optional)
override = 'override_example' # str | Asset name fragment to override (linear channel call sign or VOD asset name portion):                        to be overridden by `asset` content (None => built-in override default) (optional)
access_check = true # bool | \"Check nominal accessibility of manifest URL (from EAPI server).\" (optional) (default to true)
override_type = 'AAMP' # str | [STB] Asset override type ('AAMP' or 'XRE') (optional) (default to AAMP)

try:
    # Specifies the current streaming asset to use for auditing and testing purposes
    api_instance.set_asset(slot_id, asset, asset_index=asset_index, asset_selector=asset_selector, override=override, access_check=access_check, override_type=override_type)
except ApiException as e:
    print("Exception when calling DeviceApi->set_asset: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **asset** | **str**| URL or other identifier for asset to use (depends upon asset_index)                        (vacuous &#x3D;&gt; remove override for call_sign) |
 **asset_index** | **str**| Asset Index where asset information is stored (unspecified &#x3D;&gt; use default index) | [optional]
 **asset_selector** | **str**| Asset selector -- items heeded:                         * season:           (XS, PP) The number of the season to choose from                         * zip_code:         (PP) Simulated location (VSS) for asset playback                         * performance:      (PP) \&quot;Asset is a performance.\&quot;                         * eas:              (PP) \&quot;EAS enabled.\&quot;                         * asset_type:       (STB, XS) Type of asset (Linear, VOD, etc.)                         * channel_key:      (XS) Choose asset by some \&quot;key\&quot; to look for (example: \&quot;ep9\&quot;)                         * channel_collection (XS) Channel collection from which the linear asset is selected                                                 (expects names such as: Showtime, HBO, HLN, CBS, CNN, etc)                         * check_recent:     (XS) Check to see if there is the asset is in the recent list                                                  (expects keywords \&quot;TV\&quot; or \&quot;Movie\&quot; for VOD assets) | [optional]
 **override** | **str**| Asset name fragment to override (linear channel call sign or VOD asset name portion):                        to be overridden by &#x60;asset&#x60; content (None &#x3D;&gt; built-in override default) | [optional]
 **access_check** | **bool**| \&quot;Check nominal accessibility of manifest URL (from EAPI server).\&quot; | [optional] [default to true]
 **override_type** | **str**| [STB] Asset override type (&#x27;AAMP&#x27; or &#x27;XRE&#x27;) | [optional] [default to AAMP]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **set_controls_mode**
> set_controls_mode(slot_id, revealed)

Reveals/hides onscreen \"remote\" controls

SDK: `set_controls_mode()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
revealed = true # bool | \"Reveals onscreen controls.\" (else hides controls)

try:
    # Reveals/hides onscreen \"remote\" controls
    api_instance.set_controls_mode(slot_id, revealed)
except ApiException as e:
    print("Exception when calling DeviceApi->set_controls_mode: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **revealed** | **bool**| \&quot;Reveals onscreen controls.\&quot; (else hides controls) |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **set_setting**
> object set_setting(slot_id, setting, value)

Modifies a particular setting on this player device

SDK: `set_setting()`  Notes:  * To reduce the number of external service requests incurred, settings values assigned by this resource are    cached internally for future retrievals.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.DeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
setting = 'setting_example' # str | Name of player device setting to retrieve (case-insensitive) -- see model `DeviceSettings`                 (not all settings available for all device categories)
value = 'value_example' # str | Value to set for setting (may also be any \"truthy\" bool)

try:
    # Modifies a particular setting on this player device
    api_response = api_instance.set_setting(slot_id, setting, value)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeviceApi->set_setting: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **setting** | **str**| Name of player device setting to retrieve (case-insensitive) -- see model &#x60;DeviceSettings&#x60;                 (not all settings available for all device categories) |
 **value** | **str**| Value to set for setting (may also be any \&quot;truthy\&quot; bool) |

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

