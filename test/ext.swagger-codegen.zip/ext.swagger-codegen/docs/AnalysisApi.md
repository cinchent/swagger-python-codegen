# sdk.AnalysisApi

All URIs are relative to */api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**do_score_brisque**](AnalysisApi.md#do_score_brisque) | **POST** /analysis/score_brisque/{slot_id} | Performs BRISQUE image quality scoring on an ROI in the current stream for a fixed time duration
[**do_start_recording**](AnalysisApi.md#do_start_recording) | **POST** /analysis/start_recording/{slot_id} | Initiates frame-by-frame recording of all video frames for this player device, writing the recording to         a local file on this server system
[**do_stop_recording**](AnalysisApi.md#do_stop_recording) | **POST** /analysis/stop_recording/{slot_id} | Discontinues any stream recording currently in progress on this player device
[**get_audio_signal_status**](AnalysisApi.md#get_audio_signal_status) | **GET** /analysis/audio_signal_status/{slot_id} | Retrieves current status of audio signal from BATS Core
[**get_audio_silent**](AnalysisApi.md#get_audio_silent) | **GET** /analysis/audio_silent/{slot_id} | Uses BATS Core to determine how many consecutive frames in the device video stream are currently \&quot;silent\&quot;
[**get_audio_stats**](AnalysisApi.md#get_audio_stats) | **GET** /analysis/audio_stats/{slot_id} | Retrieves current audio statistics from BATS Core
[**get_cc_text**](AnalysisApi.md#get_cc_text) | **POST** /analysis/get_cc_text/{slot_id} | Captures a snapshot of the current screen frame, or uses a previously captured frame snapshot, and         uses OCR to extract the Closed Captioning (CC) text, if any, contained on the screen
[**get_ffwd_play_time**](AnalysisApi.md#get_ffwd_play_time) | **GET** /analysis/ffwd_play_time/{slot_id} | Captures a screenshot and performs OCR matching for the play time on the bottom portion of the frame,         presuming that playback is being fast-forwarded
[**get_frame_number**](AnalysisApi.md#get_frame_number) | **GET** /analysis/frame_number/{slot_id} | Returns the current frame count for the video device, initialized to 0 at device worker startup
[**get_image_text**](AnalysisApi.md#get_image_text) | **POST** /analysis/get_image_text/{slot_id} | Captures a snapshot of the current screen frame, or uses a previously captured frame snapshot, and         uses OCR to extract the text, if any, contained on the screen
[**get_option_selected**](AnalysisApi.md#get_option_selected) | **GET** /analysis/option_selected/{slot_id} | Captures a snapshot of the current screen frame and analyzes it to determine which menu option is currently         highlighted on the onscreen menu (if present and recognizable)
[**get_quick_channel_number**](AnalysisApi.md#get_quick_channel_number) | **GET** /analysis/quick_channel_number/{slot_id} | Captures a snapshot of the current screen frame and uses OCR on a predefined ROI to retrieve the channel         number (if present and recognizable) from it
[**get_screenshot**](AnalysisApi.md#get_screenshot) | **GET** /analysis/screenshot/{slot_id} | Captures and returns a snapshot of the current screen frame from the stream capture hardware
[**get_setting**](AnalysisApi.md#get_setting) | **GET** /analysis/setting/{slot_id} | Gets the current value for an operational setting used by the BATS Core frame analyzer
[**get_spoken_language_info**](AnalysisApi.md#get_spoken_language_info) | **GET** /analysis/spoken_language_info/{slot_id} | Captures an audio clip from the current stream and performs NLP to determine characteristics of spoken words present, as possible
[**get_video_signal_status**](AnalysisApi.md#get_video_signal_status) | **GET** /analysis/video_signal_status/{slot_id} | Retrieves current status of video signal from BATS Core
[**get_video_similarity**](AnalysisApi.md#get_video_similarity) | **GET** /analysis/video_similarity/{slot_id} | Retrieves how similar the current frame captured from the device video stream is to its predecessor
[**get_video_stationary**](AnalysisApi.md#get_video_stationary) | **GET** /analysis/video_stationary/{slot_id} | Uses BATS Core to determine how many consecutive frames in the device video stream are currently \&quot;identical\&quot;
[**get_video_stats**](AnalysisApi.md#get_video_stats) | **GET** /analysis/video_stats/{slot_id} | Retrieves current video statistics from BATS Core
[**is_audio_muted**](AnalysisApi.md#is_audio_muted) | **GET** /analysis/is_audio_muted/{slot_id} | Determines if audio appears to be \&quot;muted\&quot; (i․e․, \&quot;silent\&quot; for a continuous duration)
[**is_video_black**](AnalysisApi.md#is_video_black) | **GET** /analysis/is_video_black/{slot_id} | Determines if video display appears to currently be all \&quot;black\&quot;
[**is_video_frozen**](AnalysisApi.md#is_video_frozen) | **GET** /analysis/is_video_frozen/{slot_id} | Determines if video appears to be \&quot;frozen\&quot; (i․e․, playing the same substantially identical frame continuously)
[**reset_audio_stats**](AnalysisApi.md#reset_audio_stats) | **POST** /analysis/reset_audio_stats/{slot_id} | Resets tabulation values for audio statistics within BATS Core
[**reset_video_stats**](AnalysisApi.md#reset_video_stats) | **POST** /analysis/reset_video_stats/{slot_id} | Resets tabulation values for video statistics within BATS Core
[**set_setting**](AnalysisApi.md#set_setting) | **POST** /analysis/setting/{slot_id} | Sets an operational setting used by the BATS Core frame analyzer

# **do_score_brisque**
> list[list[object]] do_score_brisque(slot_id, duration=duration)

Performs BRISQUE image quality scoring on an ROI in the current stream for a fixed time duration

SDK: `do_score_brisque()`  Notes:  * The ROI to be scored in the stream is defined on-the-fly, and thus needn't be predefined in the current    ROI definitions file.  * An image score is produced for each scoring period in the scoring interval, where the period is determined    arbitrarily, but is no more frequent than 2 Hz.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
duration = 30.0 # float | Duration (sec) to perform BRISQUE scoring (optional) (default to 30.0)

try:
    # Performs BRISQUE image quality scoring on an ROI in the current stream for a fixed time duration
    api_response = api_instance.do_score_brisque(slot_id, duration=duration)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->do_score_brisque: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **duration** | **float**| Duration (sec) to perform BRISQUE scoring | [optional] [default to 30.0]

### Return type

**list[list[object]]**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_start_recording**
> str do_start_recording(slot_id, filespec=filespec)

Initiates frame-by-frame recording of all video frames for this player device, writing the recording to         a local file on this server system

SDK: `do_start_recording()`  Notes:  * Default file specification includes a device-specific directory and unique name with a '.webm' extension.  * Only one recording can be be in progress at any given time for each device.  * See `stop_recording()` to discontinue stream recording.  * Any recording in progress will be discontinued automatically when this player device abstraction object    is destroyed.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
filespec = 'filespec_example' # str | File specification where to store recorded video stream (None => create unique recording file) (optional)

try:
    # Initiates frame-by-frame recording of all video frames for this player device, writing the recording to         a local file on this server system
    api_response = api_instance.do_start_recording(slot_id, filespec=filespec)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->do_start_recording: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **filespec** | **str**| File specification where to store recorded video stream (None &#x3D;&gt; create unique recording file) | [optional] 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_stop_recording**
> do_stop_recording(slot_id)

Discontinues any stream recording currently in progress on this player device

SDK: `do_stop_recording()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Discontinues any stream recording currently in progress on this player device
    api_instance.do_stop_recording(slot_id)
except ApiException as e:
    print("Exception when calling AnalysisApi->do_stop_recording: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_audio_signal_status**
> AudioSignalStatus get_audio_signal_status(slot_id)

Retrieves current status of audio signal from BATS Core

SDK: `get_audio_signal_status()`  Notes:  * Audio signal status is mostly as reported by Magewell HDMI capture hardware.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Retrieves current status of audio signal from BATS Core
    api_response = api_instance.get_audio_signal_status(slot_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->get_audio_signal_status: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 

### Return type

[**AudioSignalStatus**](AudioSignalStatus.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_audio_silent**
> int get_audio_silent(slot_id)

Uses BATS Core to determine how many consecutive frames in the device video stream are currently \"silent\"

SDK: `get_audio_silent()`  Notes:  * See set_analyzer_setting() for settings that may affect the definition of audio frame silence.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Uses BATS Core to determine how many consecutive frames in the device video stream are currently \"silent\"
    api_response = api_instance.get_audio_silent(slot_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->get_audio_silent: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 

### Return type

**int**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_audio_stats**
> AudioStats get_audio_stats(slot_id)

Retrieves current audio statistics from BATS Core

SDK: `get_audio_stats()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Retrieves current audio statistics from BATS Core
    api_response = api_instance.get_audio_stats(slot_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->get_audio_stats: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 

### Return type

[**AudioStats**](AudioStats.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_cc_text**
> object get_cc_text(slot_id, image2=image2, image=image, capture=capture)

Captures a snapshot of the current screen frame, or uses a previously captured frame snapshot, and         uses OCR to extract the Closed Captioning (CC) text, if any, contained on the screen

SDK: `get_cc_text()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
image2 = 'image_example' # str |  (optional)
image = 'image_example' # str |  (optional)
capture = false # bool | \"Also return capture filespec of snapshot from which CC text is extracted.\" (optional) (default to false)

try:
    # Captures a snapshot of the current screen frame, or uses a previously captured frame snapshot, and         uses OCR to extract the Closed Captioning (CC) text, if any, contained on the screen
    api_response = api_instance.get_cc_text(slot_id, image2=image2, image=image, capture=capture)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->get_cc_text: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **image2** | **str**|  | [optional] 
 **image** | **str**|  | [optional] 
 **capture** | **bool**| \&quot;Also return capture filespec of snapshot from which CC text is extracted.\&quot; | [optional] [default to false]

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_ffwd_play_time**
> int get_ffwd_play_time(slot_id, retries=retries)

Captures a screenshot and performs OCR matching for the play time on the bottom portion of the frame,         presuming that playback is being fast-forwarded

SDK: `get_ffwd_play_time()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
retries = 5 # int | Number of times to retry OCR matching if unsuccessful (optional) (default to 5)

try:
    # Captures a screenshot and performs OCR matching for the play time on the bottom portion of the frame,         presuming that playback is being fast-forwarded
    api_response = api_instance.get_ffwd_play_time(slot_id, retries=retries)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->get_ffwd_play_time: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **retries** | **int**| Number of times to retry OCR matching if unsuccessful | [optional] [default to 5]

### Return type

**int**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_frame_number**
> int get_frame_number(slot_id)

Returns the current frame count for the video device, initialized to 0 at device worker startup

SDK: `get_frame_number()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Returns the current frame count for the video device, initialized to 0 at device worker startup
    api_response = api_instance.get_frame_number(slot_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->get_frame_number: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 

### Return type

**int**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_image_text**
> object get_image_text(slot_id, image2=image2, image=image, capture=capture)

Captures a snapshot of the current screen frame, or uses a previously captured frame snapshot, and         uses OCR to extract the text, if any, contained on the screen

SDK: `get_image_text()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
image2 = 'image_example' # str |  (optional)
image = 'image_example' # str |  (optional)
capture = false # bool | \"Also return capture filespec of snapshot from which text is extracted, if applicable.\" (optional) (default to false)

try:
    # Captures a snapshot of the current screen frame, or uses a previously captured frame snapshot, and         uses OCR to extract the text, if any, contained on the screen
    api_response = api_instance.get_image_text(slot_id, image2=image2, image=image, capture=capture)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->get_image_text: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **image2** | **str**|  | [optional] 
 **image** | **str**|  | [optional] 
 **capture** | **bool**| \&quot;Also return capture filespec of snapshot from which text is extracted, if applicable.\&quot; | [optional] [default to false]

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_option_selected**
> str get_option_selected(slot_id, filespec=filespec)

Captures a snapshot of the current screen frame and analyzes it to determine which menu option is currently         highlighted on the onscreen menu (if present and recognizable)

SDK: `get_option_selected()`  Notes:  * Default file specification is a device-specific and timestamped variation of 'episode_menu.jpg'.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
filespec = 'filespec_example' # str | File specification where to store current screen frame captured (None => default capture file) (optional)

try:
    # Captures a snapshot of the current screen frame and analyzes it to determine which menu option is currently         highlighted on the onscreen menu (if present and recognizable)
    api_response = api_instance.get_option_selected(slot_id, filespec=filespec)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->get_option_selected: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **filespec** | **str**| File specification where to store current screen frame captured (None &#x3D;&gt; default capture file) | [optional] 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_quick_channel_number**
> int get_quick_channel_number(slot_id, filespec=filespec)

Captures a snapshot of the current screen frame and uses OCR on a predefined ROI to retrieve the channel         number (if present and recognizable) from it

SDK: `get_quick_channel_number()`  Notes:  * Default file specification is a device-specific and timestamped variation of 'channel.jpg'.  * The player must be displaying the XRE Info page in order for the channel number to be extractable    (press [INFO] button or otherwise navigate to this page beforehand).  * This algorithm is sensitive to frame size and channel number position within the frame --    currently only implemented for STBs.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
filespec = 'filespec_example' # str | File specification where to store current screen frame captured (None => default capture file) (optional)

try:
    # Captures a snapshot of the current screen frame and uses OCR on a predefined ROI to retrieve the channel         number (if present and recognizable) from it
    api_response = api_instance.get_quick_channel_number(slot_id, filespec=filespec)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->get_quick_channel_number: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **filespec** | **str**| File specification where to store current screen frame captured (None &#x3D;&gt; default capture file) | [optional] 

### Return type

**int**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_screenshot**
> object get_screenshot(slot_id, filename=filename, content=content, binary=binary)

Captures and returns a snapshot of the current screen frame from the stream capture hardware

SDK: `get_screenshot()`  Notes:  * Use `device_api.get_screenshot()` to capture the image using any existing device category-specific facility.  * See `capture_screenshot()` for the default file specification.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
filename = 'filename_example' # str | File specification where to store current screen frame captured (None => default capture file) (optional)
content = true # bool | \"Return encoded BLOB containing frame content.\"  (else return filespec where content is stored) (optional) (default to true)
binary = false # bool | \"Return frame content in raw binary form. (iff content == true)\" (optional) (default to false)

try:
    # Captures and returns a snapshot of the current screen frame from the stream capture hardware
    api_response = api_instance.get_screenshot(slot_id, filename=filename, content=content, binary=binary)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->get_screenshot: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **filename** | **str**| File specification where to store current screen frame captured (None &#x3D;&gt; default capture file) | [optional] 
 **content** | **bool**| \&quot;Return encoded BLOB containing frame content.\&quot;  (else return filespec where content is stored) | [optional] [default to true]
 **binary** | **bool**| \&quot;Return frame content in raw binary form. (iff content &#x3D;&#x3D; true)\&quot; | [optional] [default to false]

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_setting**
> object get_setting(slot_id, setting)

Gets the current value for an operational setting used by the BATS Core frame analyzer

SDK: `get_setting()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
setting = 'setting_example' # str | Setting to retrieve -- see `AnalyzerSettings` model

try:
    # Gets the current value for an operational setting used by the BATS Core frame analyzer
    api_response = api_instance.get_setting(slot_id, setting)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->get_setting: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **setting** | **str**| Setting to retrieve -- see &#x60;AnalyzerSettings&#x60; model | 

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_spoken_language_info**
> SpokenLanguageInfo get_spoken_language_info(slot_id, duration=duration)

Captures an audio clip from the current stream and performs NLP to determine characteristics of spoken words present, as possible

SDK: `get_spoken_language_info()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
duration = 10.0 # float | Duration (sec) for audio capture (optional) (default to 10.0)

try:
    # Captures an audio clip from the current stream and performs NLP to determine characteristics of spoken words present, as possible
    api_response = api_instance.get_spoken_language_info(slot_id, duration=duration)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->get_spoken_language_info: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **duration** | **float**| Duration (sec) for audio capture | [optional] [default to 10.0]

### Return type

[**SpokenLanguageInfo**](SpokenLanguageInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_video_signal_status**
> VideoSignalStatus get_video_signal_status(slot_id)

Retrieves current status of video signal from BATS Core

SDK: `get_video_signal_status()`  Notes:  * Video signal status is mostly as reported by Magewell HDMI capture hardware.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Retrieves current status of video signal from BATS Core
    api_response = api_instance.get_video_signal_status(slot_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->get_video_signal_status: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 

### Return type

[**VideoSignalStatus**](VideoSignalStatus.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_video_similarity**
> float get_video_similarity(slot_id)

Retrieves how similar the current frame captured from the device video stream is to its predecessor

SDK: `get_video_similarity()`  Notes:  * See set_analyzer_setting() for settings that may affect the definition of video frame comparison.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Retrieves how similar the current frame captured from the device video stream is to its predecessor
    api_response = api_instance.get_video_similarity(slot_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->get_video_similarity: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 

### Return type

**float**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_video_stationary**
> int get_video_stationary(slot_id)

Uses BATS Core to determine how many consecutive frames in the device video stream are currently \"identical\"

SDK: `get_video_stationary()`  Notes:  * Depending upon BATS Core analyzer settings, the stream may appear stationary when a \"still\" image is    being presented within the stream content, which is a routine occurrence; it is up to the caller to    determine if this is a true indication of a \"frozen\" stream or not.  * See set_analyzer_setting() for settings that may affect the definition of video frame comparison.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Uses BATS Core to determine how many consecutive frames in the device video stream are currently \"identical\"
    api_response = api_instance.get_video_stationary(slot_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->get_video_stationary: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 

### Return type

**int**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_video_stats**
> VideoStats get_video_stats(slot_id)

Retrieves current video statistics from BATS Core

SDK: `get_video_stats()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Retrieves current video statistics from BATS Core
    api_response = api_instance.get_video_stats(slot_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->get_video_stats: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 

### Return type

[**VideoStats**](VideoStats.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **is_audio_muted**
> bool is_audio_muted(slot_id)

Determines if audio appears to be \"muted\" (i․e․, \"silent\" for a continuous duration)

SDK: `is_audio_muted()`  Notes:  * The threshold for the number of consecutive \"silent\" audio frames detected in order to consider the    stream as \"muted\" is governed by the `mute_threshold` analyzer setting (see `set_analyzer_setting()`)

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Determines if audio appears to be \"muted\" (i․e․, \"silent\" for a continuous duration)
    api_response = api_instance.is_audio_muted(slot_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->is_audio_muted: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 

### Return type

**bool**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **is_video_black**
> bool is_video_black(slot_id)

Determines if video display appears to currently be all \"black\"

SDK: `is_video_black()`  Notes:  * The greyscale threshold for the luminance level, below which a frame is considered \"black\", is governed    by the `black_threshold` analyzer setting (see `set_analyzer_setting()`)

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Determines if video display appears to currently be all \"black\"
    api_response = api_instance.is_video_black(slot_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->is_video_black: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 

### Return type

**bool**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **is_video_frozen**
> bool is_video_frozen(slot_id)

Determines if video appears to be \"frozen\" (i․e․, playing the same substantially identical frame continuously)

SDK: `is_video_frozen()`  Notes:  * The threshold for the number of consecutive \"identical\" video frames detected in order to consider the    stream as \"frozen\" is governed by the `frozen_threshold` analyzer setting (see `set_analyzer_setting()`)

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Determines if video appears to be \"frozen\" (i․e․, playing the same substantially identical frame continuously)
    api_response = api_instance.is_video_frozen(slot_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnalysisApi->is_video_frozen: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 

### Return type

**bool**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **reset_audio_stats**
> reset_audio_stats(slot_id)

Resets tabulation values for audio statistics within BATS Core

SDK: `reset_audio_stats()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Resets tabulation values for audio statistics within BATS Core
    api_instance.reset_audio_stats(slot_id)
except ApiException as e:
    print("Exception when calling AnalysisApi->reset_audio_stats: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **reset_video_stats**
> reset_video_stats(slot_id)

Resets tabulation values for video statistics within BATS Core

SDK: `reset_video_stats()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Resets tabulation values for video statistics within BATS Core
    api_instance.reset_video_stats(slot_id)
except ApiException as e:
    print("Exception when calling AnalysisApi->reset_video_stats: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **set_setting**
> set_setting(slot_id, setting, value)

Sets an operational setting used by the BATS Core frame analyzer

SDK: `set_setting()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.AnalysisApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
setting = 'setting_example' # str | Setting to affect -- see `AnalyzerSettings` model
value = 'value_example' # str | Setting value to set

try:
    # Sets an operational setting used by the BATS Core frame analyzer
    api_instance.set_setting(slot_id, setting, value)
except ApiException as e:
    print("Exception when calling AnalysisApi->set_setting: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **setting** | **str**| Setting to affect -- see &#x60;AnalyzerSettings&#x60; model | 
 **value** | **str**| Setting value to set | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

