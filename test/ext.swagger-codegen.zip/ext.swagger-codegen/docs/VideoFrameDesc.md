# VideoFrameDesc

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**seq** | **int** | BATS Core capture sequence # for video frame | 
**pts** | **int** | Presentation Timestamp (PTS) for video frame (-1 &#x3D;&gt; unknown) | 
**width** | **int** | Frame width (pixels) | 
**height** | **int** | Frame height (pixels) | 
**pixel_size** | **int** | Pixel size (bytes) | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

