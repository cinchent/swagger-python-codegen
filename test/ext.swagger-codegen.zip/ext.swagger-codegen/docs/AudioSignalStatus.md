# AudioSignalStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**signal_state** | **int** | Current state of audio input signal (&gt;0 &#x3D;&gt; enabled) | 
**num_channels** | **int** | Number of audio channels (2 &#x3D;&gt; stereo) | 
**sample_freq** | **int** | Audio sampling frequency (Hz) | 
**sample_size_bits** | **int** | Audio sample size (bits per sample) | 
**is_lpcm** | **bool** | \&quot;Audio samples are LPCM (linear PCM).\&quot; | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

