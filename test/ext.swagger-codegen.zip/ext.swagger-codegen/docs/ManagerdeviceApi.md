# sdk.ManagerdeviceApi

All URIs are relative to */api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**do_device_define**](ManagerdeviceApi.md#do_device_define) | **POST** /manager/device/define | Registers a definition for a player device or virtual player device at a particular \&quot;slot ID\&quot;, optionally         creating an entry within the player device registry (unless it is a \&quot;temporary\&quot; device)
[**do_device_release**](ManagerdeviceApi.md#do_device_release) | **POST** /manager/device/release/{slot_id} | Relinquishes exclusive use of the specified player device by the requestor, and makes it available again for         reservation
[**do_device_reserve**](ManagerdeviceApi.md#do_device_reserve) | **POST** /manager/device/reserve/{slot_id} | Reserves the specified player device for exclusive use by the requestor
[**do_device_reserve_any**](ManagerdeviceApi.md#do_device_reserve_any) | **POST** /manager/device/reserve_any | Reserves the first unreserved player device of the specified device type for exclusive use by the requestor
[**do_device_set_registry**](ManagerdeviceApi.md#do_device_set_registry) | **POST** /manager/device/set_registry | Establishes the player device registry to use to find and refer to device slot IDs, or reverts to using the         default (pre-provisioned) registry, for all subsequent device-related API requests from this BATS client
[**do_device_undefine**](ManagerdeviceApi.md#do_device_undefine) | **POST** /manager/device/undefine/{slot_id} | Undefines a player device from the device roster, removing it from the device registry unless it is a         hard-configured player device
[**do_devices_rediscover**](ManagerdeviceApi.md#do_devices_rediscover) | **POST** /manager/device/rediscover | Redefines player devices as defined within the default device registry for this requestor, and discovers their         characteristics
[**get_device_reserve**](ManagerdeviceApi.md#get_device_reserve) | **GET** /manager/device/reserve/{slot_id} | Determines which client, if any, currently holds the reservation for a player device
[**get_devices_discover**](ManagerdeviceApi.md#get_devices_discover) | **GET** /manager/device/discover | Discovers player devices defined as accessible through this EAPI server, and their characteristics, for this         requestor
[**get_service_status**](ManagerdeviceApi.md#get_service_status) | **GET** /manager/device/service_status/{slot_id} | Retrieves information about the current status of processing within this service for this device
[**set_log_verbosity**](ManagerdeviceApi.md#set_log_verbosity) | **POST** /manager/device/set_log_verbosity/{slot_id} | Dynamically controls the current logging level/sublevel for a player device

# **do_device_define**
> DeviceDefinition do_device_define(body)

Registers a definition for a player device or virtual player device at a particular \"slot ID\", optionally         creating an entry within the player device registry (unless it is a \"temporary\" device)

SDK: `do_device_define()`  Notes:  * A \"temporary\" player device is one for which `slot_id` is unspecified or empty; these are automatically    assigned an arbitrarily generated slot ID \"temp...\".

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.ManagerdeviceApi()
body = sdk.DeviceDefinition() # DeviceDefinition | 

try:
    # Registers a definition for a player device or virtual player device at a particular \"slot ID\", optionally         creating an entry within the player device registry (unless it is a \"temporary\" device)
    api_response = api_instance.do_device_define(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ManagerdeviceApi->do_device_define: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**DeviceDefinition**](DeviceDefinition.md)|  | 

### Return type

[**DeviceDefinition**](DeviceDefinition.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_device_release**
> do_device_release(slot_id, temp=temp, cleanup=cleanup)

Relinquishes exclusive use of the specified player device by the requestor, and makes it available again for         reservation

SDK: `do_device_release()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.ManagerdeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
temp = false # bool | \"Release temporary reservation.\" (optional) (default to false)
cleanup = true # bool | \"Close any BATS Core device worker and exit any open device session before releasing.\" (optional) (default to true)

try:
    # Relinquishes exclusive use of the specified player device by the requestor, and makes it available again for         reservation
    api_instance.do_device_release(slot_id, temp=temp, cleanup=cleanup)
except ApiException as e:
    print("Exception when calling ManagerdeviceApi->do_device_release: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **temp** | **bool**| \&quot;Release temporary reservation.\&quot; | [optional] [default to false]
 **cleanup** | **bool**| \&quot;Close any BATS Core device worker and exit any open device session before releasing.\&quot; | [optional] [default to true]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_device_reserve**
> DeviceDefinition do_device_reserve(slot_id, strict=strict, force=force, timeout=timeout)

Reserves the specified player device for exclusive use by the requestor

SDK: `do_device_reserve()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.ManagerdeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
strict = false # bool | \"Only reserve an unreserved device, even if requestor already holds reservation.\" (optional) (default to false)
force = false # bool | \"Forcibly usurp reservation for device if already reserved, and grant reservation to requestor.\"                 (deprecated) (optional) (default to false)
timeout = 0.0 # float | Inactivity timeout (sec): time interval after which, if there have been no API requests                 for the device, the reservation is automatically released and future API requests                 (not including the one in progress, if any) are denied                 (None/0 => persistent reservation: no auto-release) (optional) (default to 0.0)

try:
    # Reserves the specified player device for exclusive use by the requestor
    api_response = api_instance.do_device_reserve(slot_id, strict=strict, force=force, timeout=timeout)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ManagerdeviceApi->do_device_reserve: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **strict** | **bool**| \&quot;Only reserve an unreserved device, even if requestor already holds reservation.\&quot; | [optional] [default to false]
 **force** | **bool**| \&quot;Forcibly usurp reservation for device if already reserved, and grant reservation to requestor.\&quot;                 (deprecated) | [optional] [default to false]
 **timeout** | **float**| Inactivity timeout (sec): time interval after which, if there have been no API requests                 for the device, the reservation is automatically released and future API requests                 (not including the one in progress, if any) are denied                 (None/0 &#x3D;&gt; persistent reservation: no auto-release) | [optional] [default to 0.0]

### Return type

[**DeviceDefinition**](DeviceDefinition.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_device_reserve_any**
> DeviceDefinition do_device_reserve_any(devtype, force=force)

Reserves the first unreserved player device of the specified device type for exclusive use by the requestor

SDK: `do_device_reserve_any()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.ManagerdeviceApi()
devtype = 'devtype_example' # str | Device make/model/version of device to reserve
force = false # bool | \"Forcibly usurp reservation for device when already reserved.\" (optional) (default to false)

try:
    # Reserves the first unreserved player device of the specified device type for exclusive use by the requestor
    api_response = api_instance.do_device_reserve_any(devtype, force=force)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ManagerdeviceApi->do_device_reserve_any: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **devtype** | **str**| Device make/model/version of device to reserve | 
 **force** | **bool**| \&quot;Forcibly usurp reservation for device when already reserved.\&quot; | [optional] [default to false]

### Return type

[**DeviceDefinition**](DeviceDefinition.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_device_set_registry**
> list[DeviceDefinition] do_device_set_registry(registry2=registry2, title2=title2, registry=registry, title=title)

Establishes the player device registry to use to find and refer to device slot IDs, or reverts to using the         default (pre-provisioned) registry, for all subsequent device-related API requests from this BATS client

SDK: `do_device_set_registry()`  Notes:  * This registry override remains in effect only while this EAPI server remains executing;    this is not persistent.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.ManagerdeviceApi()
registry2 = 'registry_example' # str |  (optional)
title2 = 'title_example' # str |  (optional)
registry = 'registry_example' # str |  (optional)
title = 'title_example' # str |  (optional)

try:
    # Establishes the player device registry to use to find and refer to device slot IDs, or reverts to using the         default (pre-provisioned) registry, for all subsequent device-related API requests from this BATS client
    api_response = api_instance.do_device_set_registry(registry2=registry2, title2=title2, registry=registry, title=title)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ManagerdeviceApi->do_device_set_registry: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **registry2** | **str**|  | [optional] 
 **title2** | **str**|  | [optional] 
 **registry** | **str**|  | [optional] 
 **title** | **str**|  | [optional] 

### Return type

[**list[DeviceDefinition]**](DeviceDefinition.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_device_undefine**
> do_device_undefine(slot_id)

Undefines a player device from the device roster, removing it from the device registry unless it is a         hard-configured player device

SDK: `do_device_undefine()`  Notes:  * \"Hard-configured\" means any device corresponding to an attached HDMI video/audio channel on the server.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.ManagerdeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Undefines a player device from the device roster, removing it from the device registry unless it is a         hard-configured player device
    api_instance.do_device_undefine(slot_id)
except ApiException as e:
    print("Exception when calling ManagerdeviceApi->do_device_undefine: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_devices_rediscover**
> list[DeviceDefinition] do_devices_rediscover()

Redefines player devices as defined within the default device registry for this requestor, and discovers their         characteristics

SDK: `do_devices_rediscover()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.ManagerdeviceApi()

try:
    # Redefines player devices as defined within the default device registry for this requestor, and discovers their         characteristics
    api_response = api_instance.do_devices_rediscover()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ManagerdeviceApi->do_devices_rediscover: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**list[DeviceDefinition]**](DeviceDefinition.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_device_reserve**
> str get_device_reserve(slot_id)

Determines which client, if any, currently holds the reservation for a player device

SDK: `get_device_reserve()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.ManagerdeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Determines which client, if any, currently holds the reservation for a player device
    api_response = api_instance.get_device_reserve(slot_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ManagerdeviceApi->get_device_reserve: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_devices_discover**
> list[DeviceDefinition] get_devices_discover(slot_id=slot_id, devtype=devtype)

Discovers player devices defined as accessible through this EAPI server, and their characteristics, for this         requestor

SDK: `get_devices_discover()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.ManagerdeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device for which to retrieve static device definition (None => not limited to slot) (optional)
devtype = 'devtype_example' # str | Only discover devices of make/model/version (None => not limited to device type) (optional)

try:
    # Discovers player devices defined as accessible through this EAPI server, and their characteristics, for this         requestor
    api_response = api_instance.get_devices_discover(slot_id=slot_id, devtype=devtype)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ManagerdeviceApi->get_devices_discover: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device for which to retrieve static device definition (None &#x3D;&gt; not limited to slot) | [optional] 
 **devtype** | **str**| Only discover devices of make/model/version (None &#x3D;&gt; not limited to device type) | [optional] 

### Return type

[**list[DeviceDefinition]**](DeviceDefinition.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_service_status**
> DeviceServiceStatus get_service_status(slot_id)

Retrieves information about the current status of processing within this service for this device

SDK: `get_service_status()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.ManagerdeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Retrieves information about the current status of processing within this service for this device
    api_response = api_instance.get_service_status(slot_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ManagerdeviceApi->get_service_status: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 

### Return type

[**DeviceServiceStatus**](DeviceServiceStatus.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **set_log_verbosity**
> list[object] set_log_verbosity(slot_id, log_level=log_level, log_sublevel=log_sublevel)

Dynamically controls the current logging level/sublevel for a player device

SDK: `set_log_verbosity()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.ManagerdeviceApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
log_level = 'log_level_example' # str | Logging verbosity level for device: standard Python `logger` level (DEBUG, INFO, ...)                      (None => do not affect) (optional)
log_sublevel = 'log_sublevel_example' # str | Specifier (string or number) specifying log sublevel (None => not specified, do not affect) (optional)

try:
    # Dynamically controls the current logging level/sublevel for a player device
    api_response = api_instance.set_log_verbosity(slot_id, log_level=log_level, log_sublevel=log_sublevel)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ManagerdeviceApi->set_log_verbosity: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **log_level** | **str**| Logging verbosity level for device: standard Python &#x60;logger&#x60; level (DEBUG, INFO, ...)                      (None &#x3D;&gt; do not affect) | [optional] 
 **log_sublevel** | **str**| Specifier (string or number) specifying log sublevel (None &#x3D;&gt; not specified, do not affect) | [optional] 

### Return type

**list[object]**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

