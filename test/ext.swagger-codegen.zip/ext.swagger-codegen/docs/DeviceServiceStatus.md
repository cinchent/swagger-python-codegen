# DeviceServiceStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**slot_id** | **str** | Slot ID for device | [optional] 
**client_id** | **str** | Client ID of this requestor | [optional] 
**reserver** | **str** | Client ID of client holding reservation (empty if unreserved) | [optional] 
**initialized** | **bool** | \&quot;Testing/auditing session has been initialized on device.\&quot; | [optional] 
**started** | **bool** | \&quot;BATS Core analysis session has been started on device.\&quot; | [optional] 
**executing** | **str** | Name of resource currently executing on device (empty if service is idle) | [optional] 
**lifetime** | **int** | Time (sec) resource has been executing on device (0 if N/A)  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

