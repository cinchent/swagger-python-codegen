# FrameBufferSequence

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**video_descs** | [**list[VideoFrameDesc]**](VideoFrameDesc.md) | Frame descriptors for all video frames retrieved (see &#x60;VideoFrameDesc&#x60;) | 
**video_frames** | **list[str]** | Video frames captured (organization depends on capture parameters) | 
**audio_descs** | [**list[AudioFrameDesc]**](AudioFrameDesc.md) | Frame descriptors for all audio \&quot;frames\&quot; retrieved (see &#x60;AudioFrameDesc&#x60;) | 
**audio_frames** | **list[str]** | Audio frames captured (organization depends on capture parameters) | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

