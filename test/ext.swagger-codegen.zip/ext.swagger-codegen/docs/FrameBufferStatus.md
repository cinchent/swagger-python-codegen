# FrameBufferStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **bool** | \&quot;Frame buffering is enabled.\&quot;\&quot; | 
**has_video** | **bool** | \&quot;Buffer stores video frames.\&quot; | 
**has_audio** | **bool** | \&quot;Buffer stores audio frames.\&quot; | 
**capacity** | **int** | Max # video+audio frames storable in buffer | 
**frame_count** | **int** | Current # (video+audio) frames stored in buffer | 
**frame_count_video** | **int** | Current # video frames stored in buffer | 
**frame_count_audio** | **int** | Current # audio frames stored in buffer | 
**min_frame_seq_video** | **int** | Earliest video frame sequence # in buffer | 
**min_frame_seq_audio** | **int** | Earliest audio frame sequence # in buffer | 
**max_frame_seq_video** | **int** | Most recent video frame sequence # in buffer | 
**max_frame_seq_audio** | **int** | Most recent audio frame sequence # in buffer | 
**min_frame_pts_video** | **int** | Earliest video frame PTS in buffer | 
**min_frame_pts_audio** | **int** | Earliest audio frame PTS in buffer | 
**max_frame_pts_video** | **int** | Most video recent frame PTS in buffer | 
**max_frame_pts_audio** | **int** | Most audio recent frame PTS in buffer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

