# AudioFrameDesc

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**seq** | **int** | BATS Core capture sequence number for audio \&quot;frame\&quot; | 
**pts** | **int** | Presentation Timestamp (PTS) for audio \&quot;frame\&quot; (-1 &#x3D;&gt; unknown) | 
**sample_count** | **int** | Number of audio samples in audio \&quot;frame\&quot; | 
**sample_size** | **int** | Sample size (bytes) | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

