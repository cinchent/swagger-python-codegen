# sdk.TestApi

All URIs are relative to */api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**do_client_spoof**](TestApi.md#do_client_spoof) | **POST** /test/client_spoof | Initiates or cancels client spoofing, allowing a specified (or the requesting) client to masquerade as         a different client for testing purposes
[**do_file_upload**](TestApi.md#do_file_upload) | **POST** /test/file_upload | Uploads a file to this server from an existing file on the client system (or from specified content)
[**do_module_assign**](TestApi.md#do_module_assign) | **POST** /test/module_assign | Assigns a module variable or (sub)class attribute within a module namespace to a specified value
[**do_module_call**](TestApi.md#do_module_call) | **POST** /test/module_call | Calls a server-side module-global function or class/static method, optionally passing a specified or referenced argument value, and returns the function result, if any
[**do_module_import**](TestApi.md#do_module_import) | **POST** /test/module_import | (Re-)imports an existing server-side runtime module within the specified server-side parent module
[**do_shell_command**](TestApi.md#do_shell_command) | **POST** /test/shell_command | Executes an arbitrary shell command on this server
[**get_file_download**](TestApi.md#get_file_download) | **GET** /test/file_download | Downloads a file or its contents from this server
[**get_module_value**](TestApi.md#get_module_value) | **GET** /test/module_value | Retrieves the value of a module variable or (sub)class attribute within a module namespace

# **do_client_spoof**
> str do_client_spoof(client_name=client_name, new_name=new_name)

Initiates or cancels client spoofing, allowing a specified (or the requesting) client to masquerade as         a different client for testing purposes

SDK: `do_client_spoof()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.TestApi()
client_name = 'client_name_example' # str | Name (client ID public portion) of client (None => requesting client) (optional)
new_name = 'new_name_example' # str | New client ID name to masquerade as                     (`client_name` => cancel spoofing for client, None => generate from actual client name) (optional)

try:
    # Initiates or cancels client spoofing, allowing a specified (or the requesting) client to masquerade as         a different client for testing purposes
    api_response = api_instance.do_client_spoof(client_name=client_name, new_name=new_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TestApi->do_client_spoof: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **client_name** | **str**| Name (client ID public portion) of client (None &#x3D;&gt; requesting client) | [optional] 
 **new_name** | **str**| New client ID name to masquerade as                     (&#x60;client_name&#x60; &#x3D;&gt; cancel spoofing for client, None &#x3D;&gt; generate from actual client name) | [optional] 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_file_upload**
> do_file_upload(server_filespec, client_file=client_file, overwrite=overwrite, content=content, is_binary=is_binary)

Uploads a file to this server from an existing file on the client system (or from specified content)

SDK: `do_file_upload()`  Notes:  * CAUTION! This is dangerous: file destination on the server is unrestricted; inadvertently overwriting    an important file can damage the EAPI deployment or other server files.  * Current directory on the server side is the EAPI launch directory.  * File content transfer is via HTTP, so large transfers will be very slow.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.TestApi()
server_filespec = 'server_filespec_example' # str | File specification of a file on the server system to upload to
client_file = 'client_file_example' # str |  (optional)
overwrite = false # bool | \"Overwrite file on server if it exists.\" (optional) (default to false)
content = 'content_example' # str | Base64 representation of file content (None => upload `client_file`) (optional)
is_binary = false # bool | (`content` specified) \"Content is base64-encoded.\" (optional) (default to false)

try:
    # Uploads a file to this server from an existing file on the client system (or from specified content)
    api_instance.do_file_upload(server_filespec, client_file=client_file, overwrite=overwrite, content=content, is_binary=is_binary)
except ApiException as e:
    print("Exception when calling TestApi->do_file_upload: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **server_filespec** | **str**| File specification of a file on the server system to upload to | 
 **client_file** | **str**|  | [optional] 
 **overwrite** | **bool**| \&quot;Overwrite file on server if it exists.\&quot; | [optional] [default to false]
 **content** | **str**| Base64 representation of file content (None &#x3D;&gt; upload &#x60;client_file&#x60;) | [optional] 
 **is_binary** | **bool**| (&#x60;content&#x60; specified) \&quot;Content is base64-encoded.\&quot; | [optional] [default to false]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_module_assign**
> do_module_assign(target_module, target_var, source_val=source_val, source_module=source_module)

Assigns a module variable or (sub)class attribute within a module namespace to a specified value

SDK: `do_module_assign()`  Notes:  * This exists only to support internal EAPI verification and validation, not intended for client use.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.TestApi()
target_module = 'target_module_example' # str | Name of server-side module to assign a module variable within
target_var = 'target_var_example' # str | Name of target module variable to assign (dot-delimited => subobject references)
source_val = 'source_val_example' # str | Value, or name within `source_module` containing value:                        - `source_module` absent => presumed JSON, otherwise raw string                        - `source_module` provided => name to resolve (dot-delimited => subobject references)                                                      (None => same as `target_var`) (optional)
source_module = 'source_module_example' # str | Name of server-side module to look up `source_val` within (None => literal `source_val`) (optional)

try:
    # Assigns a module variable or (sub)class attribute within a module namespace to a specified value
    api_instance.do_module_assign(target_module, target_var, source_val=source_val, source_module=source_module)
except ApiException as e:
    print("Exception when calling TestApi->do_module_assign: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **target_module** | **str**| Name of server-side module to assign a module variable within | 
 **target_var** | **str**| Name of target module variable to assign (dot-delimited &#x3D;&gt; subobject references) | 
 **source_val** | **str**| Value, or name within &#x60;source_module&#x60; containing value:                        - &#x60;source_module&#x60; absent &#x3D;&gt; presumed JSON, otherwise raw string                        - &#x60;source_module&#x60; provided &#x3D;&gt; name to resolve (dot-delimited &#x3D;&gt; subobject references)                                                      (None &#x3D;&gt; same as &#x60;target_var&#x60;) | [optional] 
 **source_module** | **str**| Name of server-side module to look up &#x60;source_val&#x60; within (None &#x3D;&gt; literal &#x60;source_val&#x60;) | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_module_call**
> str do_module_call(module, funcname, arg=arg, arg_module=arg_module)

Calls a server-side module-global function or class/static method, optionally passing a specified or referenced argument value, and returns the function result, if any

SDK: `do_module_call()`  Notes:  * This exists only to support internal EAPI verification and validation, not intended for client use.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.TestApi()
module = 'module_example' # str | Module where function/method is defined
funcname = 'funcname_example' # str | Fully-qualified function/method name (dot-delimited => class/subclass references)
arg = 'arg_example' # str | Value, or name within `arg_module` containing argument value (None => no argument passed)                      - `source_module` absent => presumed JSON, otherwise raw string                      - `source_module` provided => name to resolve (dot-delimited => subobject references)                                                    (None => same as `target_var`) (optional)
arg_module = 'arg_module_example' # str | Name of server-side module to look up `source_val` within (None => literal `source_val`) (optional)

try:
    # Calls a server-side module-global function or class/static method, optionally passing a specified or referenced argument value, and returns the function result, if any
    api_response = api_instance.do_module_call(module, funcname, arg=arg, arg_module=arg_module)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TestApi->do_module_call: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **module** | **str**| Module where function/method is defined | 
 **funcname** | **str**| Fully-qualified function/method name (dot-delimited &#x3D;&gt; class/subclass references) | 
 **arg** | **str**| Value, or name within &#x60;arg_module&#x60; containing argument value (None &#x3D;&gt; no argument passed)                      - &#x60;source_module&#x60; absent &#x3D;&gt; presumed JSON, otherwise raw string                      - &#x60;source_module&#x60; provided &#x3D;&gt; name to resolve (dot-delimited &#x3D;&gt; subobject references)                                                    (None &#x3D;&gt; same as &#x60;target_var&#x60;) | [optional] 
 **arg_module** | **str**| Name of server-side module to look up &#x60;source_val&#x60; within (None &#x3D;&gt; literal &#x60;source_val&#x60;) | [optional] 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_module_import**
> str do_module_import(module, within=within, alias=alias)

(Re-)imports an existing server-side runtime module within the specified server-side parent module

SDK: `do_module_import()`  Notes:  * This exists only to support internal EAPI verification and validation, not intended for client use.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.TestApi()
module = 'module_example' # str | Name of module to import (fully-qualified, reachable on existing system path)
within = 'within_example' # str | Parent module within which to import `module` (None => import globally) (optional)
alias = 'alias_example' # str | Module alias within parent module (None => use `module` as name) (optional)

try:
    # (Re-)imports an existing server-side runtime module within the specified server-side parent module
    api_response = api_instance.do_module_import(module, within=within, alias=alias)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TestApi->do_module_import: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **module** | **str**| Name of module to import (fully-qualified, reachable on existing system path) | 
 **within** | **str**| Parent module within which to import &#x60;module&#x60; (None &#x3D;&gt; import globally) | [optional] 
 **alias** | **str**| Module alias within parent module (None &#x3D;&gt; use &#x60;module&#x60; as name) | [optional] 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_shell_command**
> str do_shell_command(cmd, timeout=timeout, tolerant=tolerant)

Executes an arbitrary shell command on this server

SDK: `do_shell_command()`  Notes:  * CAUTION! With power comes responsibility: use the same care and discretion as would befit execution    of commands from an SSH shell opened on the server.  * Current directory is the EAPI launch directory, and current user is the BATS deployment user (not root).

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.TestApi()
cmd = 'cmd_example' # str | Command line to execute at interactive server shell prompt
timeout = 1.2 # float | Timeout period (sec) allowed for shell command to execute (None => unlimited duration) (optional)
tolerant = false # bool | \"Tolerate any command execution error and always output exit code as first line.\"                  (else generate exception in case of error) (optional) (default to false)

try:
    # Executes an arbitrary shell command on this server
    api_response = api_instance.do_shell_command(cmd, timeout=timeout, tolerant=tolerant)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TestApi->do_shell_command: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cmd** | **str**| Command line to execute at interactive server shell prompt | 
 **timeout** | **float**| Timeout period (sec) allowed for shell command to execute (None &#x3D;&gt; unlimited duration) | [optional] 
 **tolerant** | **bool**| \&quot;Tolerate any command execution error and always output exit code as first line.\&quot;                  (else generate exception in case of error) | [optional] [default to false]

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_file_download**
> object get_file_download(server_filespec, content=content, is_binary=is_binary)

Downloads a file or its contents from this server

SDK: `get_file_download()`  Notes:  * CAUTION! This is insecure: file access from the server is unrestricted; any server file accessible by the    BATS deployment user can be retrieved, including sensitive files.  * Current directory on the server side is the EAPI launch directory.  * File content transfer is via HTTP, so large transfers will be very slow.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.TestApi()
server_filespec = 'server_filespec_example' # str | File specification of a file on the server system to download
content = false # bool | \"Return file content as simple result.\" (else return content as savable HTTP attachment) (optional) (default to false)
is_binary = false # bool | (`content`==True) \"Return base64-encoded result.\" (optional) (default to false)

try:
    # Downloads a file or its contents from this server
    api_response = api_instance.get_file_download(server_filespec, content=content, is_binary=is_binary)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TestApi->get_file_download: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **server_filespec** | **str**| File specification of a file on the server system to download | 
 **content** | **bool**| \&quot;Return file content as simple result.\&quot; (else return content as savable HTTP attachment) | [optional] [default to false]
 **is_binary** | **bool**| (&#x60;content&#x60;&#x3D;&#x3D;True) \&quot;Return base64-encoded result.\&quot; | [optional] [default to false]

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_module_value**
> str get_module_value(module, var)

Retrieves the value of a module variable or (sub)class attribute within a module namespace

SDK: `get_module_value()`  Notes:  * Can only retrieve a variable value that is a primitive Python data or container type.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.TestApi()
module = 'module_example' # str | Name of server-side module to retrieve a module/class variable from
var = 'var_example' # str | Name of server-side module variable to retrieve (dot-delimited => subobject references)

try:
    # Retrieves the value of a module variable or (sub)class attribute within a module namespace
    api_response = api_instance.get_module_value(module, var)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TestApi->get_module_value: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **module** | **str**| Name of server-side module to retrieve a module/class variable from | 
 **var** | **str**| Name of server-side module variable to retrieve (dot-delimited &#x3D;&gt; subobject references) | 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

