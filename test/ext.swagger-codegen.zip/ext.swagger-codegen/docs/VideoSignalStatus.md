# VideoSignalStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**signal_state** | **int** | Current state of video input signal: 0 &#x3D;&gt; NO_SIGNAL 1 &#x3D;&gt; INVALID_SIGNAL 2 &#x3D;&gt; UNLOCKED_SIGNAL 3 &#x3D;&gt; SIGNAL_OK | [optional] 
**width** | **int** | Frame resolution width (pixels) | [optional] 
**height** | **int** | Frame resolution height (pixels) | [optional] 
**frame_freq** | **float** | Frame capture frequency (Hz) | [optional] 
**color_format** | **int** | Color format for video input signal: 0 &#x3D;&gt; UNKNOWN 1 &#x3D;&gt; RGB 2 &#x3D;&gt; YUV601 3 &#x3D;&gt; YUV709 4 &#x3D;&gt; YUV2020 5 &#x3D;&gt; YUV2020C | [optional] 
**is_interlaced** | **bool** | \&quot;Stream is interlaced (resulting in halved frame capture frequency).\&quot; | [optional] 
**is_hdcp** | **bool** | \&quot;HDCP encryption in use on video input signal.\&quot; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

