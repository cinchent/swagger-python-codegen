# sdk.StbApi

All URIs are relative to */api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**do_file_grep**](StbApi.md#do_file_grep) | **POST** /stb/file_grep/{slot_id} | Searches for the occurrence(s) of an arbitrary text pattern within an STB file, optionally following         a specified line number, and searching through a possible \&quot;rollover\&quot; file
[**do_navigate_deeplink**](StbApi.md#do_navigate_deeplink) | **POST** /stb/navigate_deeplink/{slot_id} | Sends a \&quot;deeplink\&quot; HTTP request to the XAPI pertaining to this device
[**do_restart_receiver**](StbApi.md#do_restart_receiver) | **POST** /stb/restart_receiver/{slot_id} | Interacts with STB device to cause it to restart its internal receiver module
[**do_session_close**](StbApi.md#do_session_close) | **POST** /stb/session_close/{slot_id} | Closes an open pexpect shell session on this STB device
[**do_session_open**](StbApi.md#do_session_open) | **POST** /stb/session_open/{slot_id} | Opens a pexpect shell session on this STB device
[**do_shell_command**](StbApi.md#do_shell_command) | **POST** /stb/shell_command/{slot_id} | Executes an arbitrary shell command on this STB
[**do_xapi_command**](StbApi.md#do_xapi_command) | **POST** /stb/xapi_command/{slot_id} | Issues a generic HTTP request \&quot;command\&quot; to the XRE API (XAPI), optionally pertaining to this device
[**get_receiver_trace_id**](StbApi.md#get_receiver_trace_id) | **GET** /stb/receiver_trace_id/{slot_id} | Extracts the most recent trace ID from the receiver log on the STB device
[**get_xapi_status**](StbApi.md#get_xapi_status) | **GET** /stb/xapi_status/{slot_id} | Retrieves the XAPI status for this device

# **do_file_grep**
> str do_file_grep(slot_id, pattern, filespec, rollover_ext=rollover_ext, startline=startline, options=options, timeout=timeout)

Searches for the occurrence(s) of an arbitrary text pattern within an STB file, optionally following         a specified line number, and searching through a possible \"rollover\" file

SDK: `do_file_grep()`  Notes:  * This search algorithm supports files that can be growing or whose contents rotate to a \"rollover\" file;    searches the \"main\" file specified, but also the rollover file when rotation is detected.  * Timeout for a failed search may actually be up to a few times the specified timeout due to retries.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.StbApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
pattern = 'pattern_example' # str | Regular expression specifying text pattern to search for (cannot span lines)
filespec = 'filespec_example' # str | File specification for file on STB to search
rollover_ext = '.1' # str | File extension for first \"rollover\" file of `filespec` (None => file doesn't roll over) (optional) (default to .1)
startline = 0 # int | Starting line number after which to search for the occurrence of `pattern`                      (must be < number of lines in file, or a \"rollover\" is assumed) (optional) (default to 0)
options = 'options_example' # str | Additional command-line options for `grep` command (optional)
timeout = 30.0 # float | Timeout period (sec) allowed for (repeated) search (None => unlimited duration) (optional) (default to 30.0)

try:
    # Searches for the occurrence(s) of an arbitrary text pattern within an STB file, optionally following         a specified line number, and searching through a possible \"rollover\" file
    api_response = api_instance.do_file_grep(slot_id, pattern, filespec, rollover_ext=rollover_ext, startline=startline, options=options, timeout=timeout)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling StbApi->do_file_grep: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **pattern** | **str**| Regular expression specifying text pattern to search for (cannot span lines) |
 **filespec** | **str**| File specification for file on STB to search |
 **rollover_ext** | **str**| File extension for first \&quot;rollover\&quot; file of &#x60;filespec&#x60; (None &#x3D;&gt; file doesn&#x27;t roll over) | [optional] [default to .1]
 **startline** | **int**| Starting line number after which to search for the occurrence of &#x60;pattern&#x60;                      (must be &lt; number of lines in file, or a \&quot;rollover\&quot; is assumed) | [optional] [default to 0]
 **options** | **str**| Additional command-line options for &#x60;grep&#x60; command | [optional]
 **timeout** | **float**| Timeout period (sec) allowed for (repeated) search (None &#x3D;&gt; unlimited duration) | [optional] [default to 30.0]

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_navigate_deeplink**
> object do_navigate_deeplink(slot_id, deeplink, method=method, params=params)

Sends a \"deeplink\" HTTP request to the XAPI pertaining to this device

SDK: `do_navigate_deeplink()`  Notes:  * Specified `params` are included as query parameters for GET requests and as form data for POST requests.  * This resource is solely for accessing XAPI deeplinks verbatim; no processing or filtering of query parameters    or request data is performed.  * For specific information about the deeplinks available through the XAPI, see:    https://etwiki.sys.XXXXXXX.net/pages/viewpage.action?spaceKey=xcalPDEV&title=XAPI+Service++Specification    and https://etwiki.sys.XXXXXXX.net/pages/viewpage.action?spaceKey=X2TP&title=X2+Deeplinks

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.StbApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
deeplink = 'deeplink_example' # str | XAPI deeplink URL to invoke (not validated for correctness by this resource): full URL,                  including 'xre' scheme
method = 'get' # str | HTTP method (GET or POST) (optional) (default to get)
params = 'params_example' # str | Dictionary of query parameters or data to qualify the deeplink (None => no parameters) (optional)

try:
    # Sends a \"deeplink\" HTTP request to the XAPI pertaining to this device
    api_response = api_instance.do_navigate_deeplink(slot_id, deeplink, method=method, params=params)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling StbApi->do_navigate_deeplink: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **deeplink** | **str**| XAPI deeplink URL to invoke (not validated for correctness by this resource): full URL,                  including &#x27;xre&#x27; scheme |
 **method** | **str**| HTTP method (GET or POST) | [optional] [default to get]
 **params** | **str**| Dictionary of query parameters or data to qualify the deeplink (None &#x3D;&gt; no parameters) | [optional]

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_restart_receiver**
> bool do_restart_receiver(slot_id, timeout=timeout)

Interacts with STB device to cause it to restart its internal receiver module

SDK: `do_restart_receiver()`  Notes:  * Executes synchronously, not returning until receiver is (presumably) restarted.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.StbApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
timeout = 300.0 # float | Timeout period (sec), within which restart is expected to complete (optional) (default to 300.0)

try:
    # Interacts with STB device to cause it to restart its internal receiver module
    api_response = api_instance.do_restart_receiver(slot_id, timeout=timeout)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling StbApi->do_restart_receiver: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **timeout** | **float**| Timeout period (sec), within which restart is expected to complete | [optional] [default to 300.0]

### Return type

**bool**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_session_close**
> do_session_close(slot_id)

Closes an open pexpect shell session on this STB device

SDK: `do_session_close()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.StbApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Closes an open pexpect shell session on this STB device
    api_instance.do_session_close(slot_id)
except ApiException as e:
    print("Exception when calling StbApi->do_session_close: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_session_open**
> str do_session_open(slot_id, allow_fail=allow_fail, connection_attempts=connection_attempts, inactivity_timeout=inactivity_timeout)

Opens a pexpect shell session on this STB device

SDK: `do_session_open()`  Notes:  * Do not specify an `inactivity_timeout` value of 0 unless you know exactly what you are doing.    (Sessions sitting idle in perpetuity consume a Jump Server session from its quota.)  * Side-effect: saves opened session in this object.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.StbApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
allow_fail = false # bool | \"Don't raise PlayerDeviceError upon failure to establish a session.\" (optional) (default to false)
connection_attempts = 3 # int | Maximum number of times to attempt to open a session to the STB before failing out (optional) (default to 3)
inactivity_timeout = 600.0 # float | Maximum duration between shell commands or output production                             tolerated before automatically closing session (sec); 0 => no timeout (optional) (default to 600.0)

try:
    # Opens a pexpect shell session on this STB device
    api_response = api_instance.do_session_open(slot_id, allow_fail=allow_fail, connection_attempts=connection_attempts, inactivity_timeout=inactivity_timeout)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling StbApi->do_session_open: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **allow_fail** | **bool**| \&quot;Don&#x27;t raise PlayerDeviceError upon failure to establish a session.\&quot; | [optional] [default to false]
 **connection_attempts** | **int**| Maximum number of times to attempt to open a session to the STB before failing out | [optional] [default to 3]
 **inactivity_timeout** | **float**| Maximum duration between shell commands or output production                             tolerated before automatically closing session (sec); 0 &#x3D;&gt; no timeout | [optional] [default to 600.0]

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_shell_command**
> str do_shell_command(slot_id, cmd, timeout=timeout, retries=retries)

Executes an arbitrary shell command on this STB

SDK: `do_shell_command()`  Notes:  * The existing shell session is used, if currently open; otherwise, a new temporary shell session,    lasting only for the duration of this command, is opened then closed.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.StbApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
cmd = 'cmd_example' # str | Command line to execute at interactive STB shell prompt
timeout = 1.2 # float | Timeout period (sec) allowed for shell command to execute on STB                 (None => unlimited duration) (optional)
retries = 0 # int | Number of times to retry a command on the STB if it fails (optional) (default to 0)

try:
    # Executes an arbitrary shell command on this STB
    api_response = api_instance.do_shell_command(slot_id, cmd, timeout=timeout, retries=retries)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling StbApi->do_shell_command: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **cmd** | **str**| Command line to execute at interactive STB shell prompt |
 **timeout** | **float**| Timeout period (sec) allowed for shell command to execute on STB                 (None &#x3D;&gt; unlimited duration) | [optional]
 **retries** | **int**| Number of times to retry a command on the STB if it fails | [optional] [default to 0]

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_xapi_command**
> object do_xapi_command(slot_id, endpoint, method=method, params=params, device=device)

Issues a generic HTTP request \"command\" to the XRE API (XAPI), optionally pertaining to this device

SDK: `do_xapi_command()`  Notes:  * HTTP GET and POST methods are supported by XAPI.  * Specified `params` are included as query parameters for GET requests and as form data for POST requests.  * This resource is solely for passing XAPI requests through verbatim; no processing or filtering of query    parameters or request data is performed.  * For specific information about the requests available through the XAPI and their endpoints, see:    https://etwiki.sys.XXXXXXX.net/pages/viewpage.action?spaceKey=xcalPDEV&title=XAPI+Service++Specification

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.StbApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
endpoint = 'endpoint_example' # str | XAPI endpoint name to invoke (simple name, without .js; correctness not validated by EAPI)
method = 'get' # str | HTTP method (GET or POST) (optional) (default to get)
params = 'params_example' # str | Dictionary containing query parameters or data to accompany request (None => no parameters) (optional)
device = true # bool | \"Device-specific request.\"  (else not specific to any device) (optional) (default to true)

try:
    # Issues a generic HTTP request \"command\" to the XRE API (XAPI), optionally pertaining to this device
    api_response = api_instance.do_xapi_command(slot_id, endpoint, method=method, params=params, device=device)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling StbApi->do_xapi_command: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **endpoint** | **str**| XAPI endpoint name to invoke (simple name, without .js; correctness not validated by EAPI) |
 **method** | **str**| HTTP method (GET or POST) | [optional] [default to get]
 **params** | **str**| Dictionary containing query parameters or data to accompany request (None &#x3D;&gt; no parameters) | [optional]
 **device** | **bool**| \&quot;Device-specific request.\&quot;  (else not specific to any device) | [optional] [default to true]

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_receiver_trace_id**
> str get_receiver_trace_id(slot_id, timeout=timeout)

Extracts the most recent trace ID from the receiver log on the STB device

SDK: `get_receiver_trace_id()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.StbApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
timeout = 60.0 # float | Timeout period (sec) allowed for trace ID to be extracted (None => unlimited duration) (optional) (default to 60.0)

try:
    # Extracts the most recent trace ID from the receiver log on the STB device
    api_response = api_instance.get_receiver_trace_id(slot_id, timeout=timeout)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling StbApi->get_receiver_trace_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |
 **timeout** | **float**| Timeout period (sec) allowed for trace ID to be extracted (None &#x3D;&gt; unlimited duration) | [optional] [default to 60.0]

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_xapi_status**
> object get_xapi_status(slot_id)

Retrieves the XAPI status for this device

SDK: `get_xapi_status()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.StbApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server

try:
    # Retrieves the XAPI status for this device
    api_response = api_instance.get_xapi_status(slot_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling StbApi->get_xapi_status: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server |

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

