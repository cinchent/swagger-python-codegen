# DeviceDefinition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lab** | **str** | Lab (site/facility) where device resides (None &#x3D;&gt; N/A) | [optional]
**server** | **str** | Server system having slot for device attachment (None &#x3D;&gt; no HDMI attachment) | [optional]
**slot_id** | **str** | Slot ID for device as accessible to server | [optional]
**category** | **str** | Player device category (one of: {&#x27;Gateway&#x27;, &#x27;STB&#x27;, &#x27;SSP&#x27;, &#x27;VSP&#x27;}) | [optional]
**name** | **str** | Make/Model/Version of player device | [optional]
**description** | **str** | Description of device make/model/version | [optional]
**partner** | **str** | Partner providing device/firmware (None &#x3D;&gt; XXXXXXX) | [optional]
**web_stream** | **str** | Web path for device output stream | [optional]
**video** | **str** | System device name for video device (vacuous &#x3D;&gt; virtual device) | [optional]
**audio** | **str** | System audio channel for audio device | [optional]
**url** | **str** | URL of input stream for virtual device (vacuous &#x3D;&gt; real device) | [optional]
**xray_id** | **str** | [STB] Device ID code in X-Ray for device | [optional]
**xray_model** | **str** | [STB] Model ID code in X-Ray for device | [optional]
**ecm_mac** | **str** | [Gateway] eCM MAC address for Gateway device (:-delimited) (vacuous &#x3D;&gt; N/A) | [optional]
**estb_mac** | **str** | [STB] eSTB MAC address for device (:-delimited) (vacuous &#x3D;&gt; N/A) | [optional]
**estb_ip** | **str** | [STB] IPv6 address address for device (:-delimited) (vacuous &#x3D;&gt; N/A) | [optional]
**platform** | **str** | [SSP] Execution platform for device | [optional]
**hostname** | **str** | [SSP] Network hostname/IP of SSPC hub for device | [optional]
**port** | **int** | [SSP] Network port of SSPC host driver for device | [optional]
**capabilities** | **str** | [SSP] File or JSON BLOB describing SSP capabilities (vacuous &#x3D;&gt; SSP device type defaults) | [optional]
**offline** | **bool** | Whether device is offline (true) or available (false) | [optional]
**reservation** | **str** | Reservation for device (vacuous &#x3D;&gt; unreserved) | [optional]
**message** | **str** | Failure reason | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

