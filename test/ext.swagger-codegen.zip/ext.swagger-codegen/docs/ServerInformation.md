# ServerInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_remote** | **bool** | \&quot;EAPI Service is hosted on a BATS server.\&quot; | [optional] 
**eapi** | **object** | EAPI Service Information | [optional] 
**bats_core** | **object** | BATS Core Information | [optional] 
**capabilities** | **object** | EAPI/BATS Core Capabilities | [optional] 
**up_time** | **int** | Time (sec) since EAPI Service started | [optional] 
**last_request** | **int** | Time (sec) since last request completion (- if no requests) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

