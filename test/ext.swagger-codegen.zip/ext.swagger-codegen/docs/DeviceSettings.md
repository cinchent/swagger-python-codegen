# DeviceSettings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cc** | **bool** | Closed-captioning enablement state (\&quot;truthy\&quot; value: 0&#x3D;&gt;disabled, 1&#x3D;&gt;enabled) | [optional] 
**cc_font_size** | **str** | Closed-captioning font size -- one of: [&#x27;MEDIUM&#x27;, &#x27;LARGE&#x27;, &#x27;SMALL&#x27;] | [optional] 
**cc_font_style** | **str** | Closed-captioning text style -- one of: [&#x27;DEFAULT&#x27;, &#x27;CASUAL&#x27;, &#x27;MONOSPACED_SERIF&#x27;] | [optional] 
**cc_font_color** | **str** | Closed-captioning font color -- one of: [&#x27;WHITE&#x27;, &#x27;BLACK&#x27;, &#x27;RED&#x27;, &#x27;GREEN&#x27;, &#x27;BLUE&#x27;, &#x27;YELLOW&#x27;] | [optional] 
**cc_font_opacity** | **str** | Closed-captioning font opacity -- one of: [&#x27;SOLID&#x27;, &#x27;TRANSPARENT&#x27;, &#x27;TRANSLUCENT&#x27;] | [optional] 
**cc_font_edge_style** | **str** | Closed-captioning font edge style -- one of: [&#x27;NONE&#x27;, &#x27;RAISED&#x27;, &#x27;DEPRESSED&#x27;, &#x27;UNIFORM&#x27;] | [optional] 
**cc_font_edge_color** | **str** | Closed-captioning font edge color -- one of: [&#x27;BLACK&#x27;, &#x27;RED&#x27;, &#x27;GREEN&#x27;, &#x27;BLUE&#x27;, &#x27;YELLOW&#x27;, &#x27;WHITE&#x27;] | [optional] 
**cc_background_color** | **str** | Closed-captioning background color -- one of: [&#x27;BLACK&#x27;, &#x27;RED&#x27;, &#x27;BLUE&#x27;, &#x27;YELLOW&#x27;, &#x27;WHITE&#x27;] | [optional] 
**cc_background_opacity** | **str** | Closed-captioning background opacity -- one of: [&#x27;SOLID&#x27;, &#x27;TRANSPARENT&#x27;, &#x27;TRANSLUCENT&#x27;] | [optional] 
**window_color** | **str** | Closed-captioning window color -- one of: [&#x27;BLACK&#x27;, &#x27;RED&#x27;, &#x27;GREEN&#x27;, &#x27;BLUE&#x27;, &#x27;YELLOW&#x27;, &#x27;WHITE&#x27;] | [optional] 
**window_opacity** | **str** | Closed-captioning window opacity -- one of: [&#x27;TRANSPARENT&#x27;, &#x27;TRANSLUCENT&#x27;, &#x27;SOLID&#x27;] | [optional] 
**attr_type** | **str** | Closed-captioning attribute type -- one of: [&#x27;DIGITAL&#x27;, &#x27;ANALOG&#x27;] | [optional] 
**sap** | **bool** | Secondary Audio Program enablement state (\&quot;truthy\&quot; value) | [optional] 
**saplang** | **str** | Secondary Audio Program language selected (must be in current asset profile) | [optional] 
**guidelang** | **str** | Guide screen language selected | [optional] 
**voiceguide** | **bool** | Voice guidance enablement state (\&quot;truthy\&quot; value: 0&#x3D;&gt;disabled, 1&#x3D;&gt;enabled) | [optional] 
**dvs** | **bool** | Video description enablement state (\&quot;truthy\&quot; value: 0&#x3D;&gt;disabled, 1&#x3D;&gt;enabled) | [optional] 
**hdpref** | **bool** | HD Auto-Retune enablement state (\&quot;truthy\&quot; value: 0&#x3D;&gt;disabled, 1&#x3D;&gt;enabled) | [optional] 
**sstimeout** | **int** | Screen Saver Inactivity timeout (sec) -- one of: [300, 900, 1800, 18000, 0], 0&#x3D;&gt;no screensaver | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

