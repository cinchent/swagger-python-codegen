# SpokenLanguageInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**service_status** | **str** | Status indication from language analysis service (COMPLETED &#x3D;&gt; ok) | [optional] 
**language_code** | **str** | ISO language code of spoken language (None &#x3D;&gt; unknown/indeterminate) | [optional] 
**language_name** | **str** | Language name of spoken language (None &#x3D;&gt; unknown/indeterminate) | [optional] 
**analysis_confidence** | **float** | Confidence % for language analysis | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

