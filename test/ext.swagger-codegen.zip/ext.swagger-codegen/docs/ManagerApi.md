# sdk.ManagerApi

All URIs are relative to */api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**do_authorize**](ManagerApi.md#do_authorize) | **POST** /manager/authorize | Provide credentials for resources requiring authorization
[**do_quality_services_start**](ManagerApi.md#do_quality_services_start) | **POST** /manager/quality_services_start | (Re)starts the &#x60;quality&#x60; services for all player devices attached to this BATS server
[**do_quality_services_stop**](ManagerApi.md#do_quality_services_stop) | **POST** /manager/quality_services_stop | Stops the &#x60;quality&#x60; services for all player devices attached to this BATS server
[**do_service_restart**](ManagerApi.md#do_service_restart) | **POST** /manager/service_restart | Restarts this EAPI service instance
[**do_service_stop**](ManagerApi.md#do_service_stop) | **POST** /manager/service_stop | Stops this EAPI service instance
[**do_streaming_start**](ManagerApi.md#do_streaming_start) | **POST** /manager/streaming_start | (Re)starts the BATS streaming service for all player devices attached to this BATS server
[**do_streaming_stop**](ManagerApi.md#do_streaming_stop) | **POST** /manager/streaming_stop | Stops the BATS streaming service for all player devices attached to this BATS server
[**do_web_gui_restart**](ManagerApi.md#do_web_gui_restart) | **POST** /manager/web_gui_restart | Restarts the BATS WebGUI services for all player devices attached to this BATS server
[**get_server_info**](ManagerApi.md#get_server_info) | **GET** /manager/server_info | Retrieves information about this EAPI service, BATS Core, and BATS server platform
[**set_log_verbosity**](ManagerApi.md#set_log_verbosity) | **POST** /manager/set_log_verbosity | Dynamically controls the current logging level

# **do_authorize**
> bool do_authorize(password2=password2, password=password, username=username)

Provide credentials for resources requiring authorization

SDK: `do_authorize()`  Notes:  * This is a very basic, low-security authorization mechanism.  * This resource is provided for SDK use only; from the Swagger GUI, use the [Authorize] button above instead.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.ManagerApi()
password2 = 'password_example' # str |  (optional)
password = 'password_example' # str |  (optional)
username = 'username_example' # str | Username for authorization request (None => validate password without username) (optional)

try:
    # Provide credentials for resources requiring authorization
    api_response = api_instance.do_authorize(password2=password2, password=password, username=username)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ManagerApi->do_authorize: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **password2** | [**str**](.md)|  | [optional] 
 **password** | [**str**](.md)|  | [optional] 
 **username** | **str**| Username for authorization request (None &#x3D;&gt; validate password without username) | [optional] 

### Return type

**bool**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_quality_services_start**
> do_quality_services_start(restart=restart)

(Re)starts the `quality` services for all player devices attached to this BATS server

SDK: `do_quality_services_start()`  Notes:  * At this time, quality services are provided by SSIMWAVE; this starts all licensed and configured SSIMWAVE    LiveMonitor services installed on this BATS server.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint
# Configure HTTP basic authorization: basicAuth
configuration = sdk.Configuration()
configuration.username = 'YOUR_USERNAME'
configuration.password = 'YOUR_PASSWORD'

# create an instance of the API class
api_instance = sdk.ManagerApi(sdk.ApiClient(configuration))
restart = false # bool | \"Restart quality services.\" (else start it initially) (optional) (default to false)

try:
    # (Re)starts the `quality` services for all player devices attached to this BATS server
    api_instance.do_quality_services_start(restart=restart)
except ApiException as e:
    print("Exception when calling ManagerApi->do_quality_services_start: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **restart** | **bool**| \&quot;Restart quality services.\&quot; (else start it initially) | [optional] [default to false]

### Return type

void (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_quality_services_stop**
> do_quality_services_stop()

Stops the `quality` services for all player devices attached to this BATS server

SDK: `do_quality_services_stop()`  Notes:  * At this time, quality services are provided by SSIMWAVE; this stops all licensed and configured SSIMWAVE    LiveMonitor services installed on this BATS server.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint
# Configure HTTP basic authorization: basicAuth
configuration = sdk.Configuration()
configuration.username = 'YOUR_USERNAME'
configuration.password = 'YOUR_PASSWORD'

# create an instance of the API class
api_instance = sdk.ManagerApi(sdk.ApiClient(configuration))

try:
    # Stops the `quality` services for all player devices attached to this BATS server
    api_instance.do_quality_services_stop()
except ApiException as e:
    print("Exception when calling ManagerApi->do_quality_services_stop: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_service_restart**
> do_service_restart()

Restarts this EAPI service instance

SDK: `do_service_restart()`  Notes:  * This will dissolve any existing connection sessions executing on this server, causing testing/auditing    operations in progress to fail, possibly unrecoverably.  * For a production instance, this request will result in a 504 GATEWAY TIMEOUT status in case of a *successful*    service restart.  * For a development instance, this request will result in a 410 GONE status and will shut down the service;    the EAPI service must then be restarted manually.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint
# Configure HTTP basic authorization: basicAuth
configuration = sdk.Configuration()
configuration.username = 'YOUR_USERNAME'
configuration.password = 'YOUR_PASSWORD'

# create an instance of the API class
api_instance = sdk.ManagerApi(sdk.ApiClient(configuration))

try:
    # Restarts this EAPI service instance
    api_instance.do_service_restart()
except ApiException as e:
    print("Exception when calling ManagerApi->do_service_restart: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_service_stop**
> do_service_stop()

Stops this EAPI service instance

SDK: `do_service_stop()`  Notes:  * This will dissolve any existing connection sessions executing on this server, causing testing/auditing    operations in progress to fail, possibly unrecoverably.  * For a production instance, this request will result in a 504 GATEWAY TIMEOUT status in case of a *successful*    service stoppage.  * For a development instance, this request will result in a 410 GONE status and will shut down the service.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint
# Configure HTTP basic authorization: basicAuth
configuration = sdk.Configuration()
configuration.username = 'YOUR_USERNAME'
configuration.password = 'YOUR_PASSWORD'

# create an instance of the API class
api_instance = sdk.ManagerApi(sdk.ApiClient(configuration))

try:
    # Stops this EAPI service instance
    api_instance.do_service_stop()
except ApiException as e:
    print("Exception when calling ManagerApi->do_service_stop: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_streaming_start**
> do_streaming_start(restart=restart)

(Re)starts the BATS streaming service for all player devices attached to this BATS server

SDK: `do_streaming_start()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint
# Configure HTTP basic authorization: basicAuth
configuration = sdk.Configuration()
configuration.username = 'YOUR_USERNAME'
configuration.password = 'YOUR_PASSWORD'

# create an instance of the API class
api_instance = sdk.ManagerApi(sdk.ApiClient(configuration))
restart = false # bool | \"Restart streaming service.\" (else start it initially) (optional) (default to false)

try:
    # (Re)starts the BATS streaming service for all player devices attached to this BATS server
    api_instance.do_streaming_start(restart=restart)
except ApiException as e:
    print("Exception when calling ManagerApi->do_streaming_start: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **restart** | **bool**| \&quot;Restart streaming service.\&quot; (else start it initially) | [optional] [default to false]

### Return type

void (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_streaming_stop**
> do_streaming_stop()

Stops the BATS streaming service for all player devices attached to this BATS server

SDK: `do_streaming_stop()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint
# Configure HTTP basic authorization: basicAuth
configuration = sdk.Configuration()
configuration.username = 'YOUR_USERNAME'
configuration.password = 'YOUR_PASSWORD'

# create an instance of the API class
api_instance = sdk.ManagerApi(sdk.ApiClient(configuration))

try:
    # Stops the BATS streaming service for all player devices attached to this BATS server
    api_instance.do_streaming_stop()
except ApiException as e:
    print("Exception when calling ManagerApi->do_streaming_stop: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_web_gui_restart**
> do_web_gui_restart()

Restarts the BATS WebGUI services for all player devices attached to this BATS server

SDK: `do_web_gui_restart()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint
# Configure HTTP basic authorization: basicAuth
configuration = sdk.Configuration()
configuration.username = 'YOUR_USERNAME'
configuration.password = 'YOUR_PASSWORD'

# create an instance of the API class
api_instance = sdk.ManagerApi(sdk.ApiClient(configuration))

try:
    # Restarts the BATS WebGUI services for all player devices attached to this BATS server
    api_instance.do_web_gui_restart()
except ApiException as e:
    print("Exception when calling ManagerApi->do_web_gui_restart: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_server_info**
> ServerInformation get_server_info()

Retrieves information about this EAPI service, BATS Core, and BATS server platform

SDK: `get_server_info()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.ManagerApi()

try:
    # Retrieves information about this EAPI service, BATS Core, and BATS server platform
    api_response = api_instance.get_server_info()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ManagerApi->get_server_info: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ServerInformation**](ServerInformation.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **set_log_verbosity**
> str set_log_verbosity(log_level=log_level)

Dynamically controls the current logging level

SDK: `set_log_verbosity()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint
# Configure HTTP basic authorization: basicAuth
configuration = sdk.Configuration()
configuration.username = 'YOUR_USERNAME'
configuration.password = 'YOUR_PASSWORD'

# create an instance of the API class
api_instance = sdk.ManagerApi(sdk.ApiClient(configuration))
log_level = 'log_level_example' # str | Logging verbosity level to set: standard Python `logger` level (DEBUG, INFO, ...)                   (None => do not affect) (optional)

try:
    # Dynamically controls the current logging level
    api_response = api_instance.set_log_verbosity(log_level=log_level)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ManagerApi->set_log_verbosity: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **log_level** | **str**| Logging verbosity level to set: standard Python &#x60;logger&#x60; level (DEBUG, INFO, ...)                   (None &#x3D;&gt; do not affect) | [optional] 

### Return type

**str**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

