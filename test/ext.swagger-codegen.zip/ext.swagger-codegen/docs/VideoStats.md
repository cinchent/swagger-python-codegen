# VideoStats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_frames** | **int** | Total # frames analyzed | [optional] 
**total_batches** | **int** | Number of backlog batches processed | [optional] 
**max_backlog** | **int** | Maximum # frames accumulated in backlog | [optional] 
**total_identical** | **int** | Total # frames \&quot;identical\&quot; to previous in stream | [optional] 
**max_identical** | **int** | Maximum # consecutive frames \&quot;identical\&quot; to previous in stream | [optional] 
**total_black** | **int** | Total # video frames deemed \&quot;black\&quot; | [optional] 
**max_black** | **int** | Maximum # consecutive video frames deemed \&quot;black\&quot; | [optional] 
**total_frames_lost** | **int** | Total # available video frames uncaptured | [optional] 
**max_frames_lost** | **int** | Maximum # consecutive video frames uncaptured | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

