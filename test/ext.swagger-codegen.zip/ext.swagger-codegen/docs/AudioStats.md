# AudioStats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_frames** | **int** | Total # frames analyzed | [optional] 
**total_batches** | **int** | Number of backlog batches processed | [optional] 
**max_backlog** | **int** | Maximum # frames accumulated in backlog | [optional] 
**total_identical** | **int** | Total # frames \&quot;identical\&quot; to previous in stream | [optional] 
**max_identical** | **int** | Maximum # consecutive frames \&quot;identical\&quot; to previous in stream | [optional] 
**total_silent** | **int** | Total # audio frames deemed \&quot;silent\&quot; | [optional] 
**max_silent** | **int** | Maximum # consecutive audio frames deemed \&quot;silent\&quot; | [optional] 
**total_samples** | **int** | Total # individual audio samples processed | [optional] 
**amplitude_min** | **int** | Maximum negative amplitude among all audio samples | [optional] 
**amplitude_max** | **int** | Maximum positive amplitude among all audio samples | [optional] 
**total_frames_lost** | **int** | Total # available audio frames uncaptured | [optional] 
**max_frames_lost** | **int** | Maximum # consecutive audio frames uncaptured | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

