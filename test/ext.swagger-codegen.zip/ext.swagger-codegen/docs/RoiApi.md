# sdk.RoiApi

All URIs are relative to */api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**do_add_ocr_roi**](RoiApi.md#do_add_ocr_roi) | **POST** /roi/add_ocr_roi/{slot_id} | Adds an Optical Character Recognition (OCR) Region-Of-Interest (ROI) definition to the collection of ROIs         currently being detected by BATS in the device video stream
[**do_add_roi**](RoiApi.md#do_add_roi) | **POST** /roi/add_roi/{slot_id} | Adds a Region-Of-Interest (ROI) definition to the collection of ROIs currently being detected by BATS in the         device video stream
[**do_add_roi_from_asset**](RoiApi.md#do_add_roi_from_asset) | **POST** /roi/add_roi_from_asset/{slot_id} | Acquires a particular frame from the stream for an asset, creates a Region-Of-Interest (ROI) for that frame         (or some subset of it), and initiates matching for that ROI
[**do_add_roi_from_image**](RoiApi.md#do_add_roi_from_image) | **POST** /roi/add_roi_from_image/{slot_id} | Generates a ROI from an image (or optionally, a portion thereof), and optionally initiates matching for that ROI
[**do_match_rois**](RoiApi.md#do_match_rois) | **POST** /roi/match_rois/{slot_id} | Determines which of the specified ROI(s) among the collection of ROIs currently being detected by BATS         in the device video stream have been matched
[**do_match_rois_with_scores**](RoiApi.md#do_match_rois_with_scores) | **POST** /roi/match_rois_with_scores/{slot_id} | Submits a collection of ROIs to BATS for it to match in realtime against the incoming video stream for         a specified duration, using the specified matching threshold, returning all ROIs matched and the match degree         for each
[**do_remove_roi**](RoiApi.md#do_remove_roi) | **POST** /roi/remove_roi/{slot_id} | Removes a Region-Of-Interest (ROI) definition from the collection of ROIs currently being detected by BATS         in the device video stream
[**set_roi_defs**](RoiApi.md#set_roi_defs) | **POST** /roi/set_roi_defs/{slot_id} | Specifies the file defining all Regions-Of-Interest (ROIs) to detect in the video stream for this device,         and (optionally) returns the ROIs within that file

# **do_add_ocr_roi**
> do_add_ocr_roi(slot_id, roi_name)

Adds an Optical Character Recognition (OCR) Region-Of-Interest (ROI) definition to the collection of ROIs         currently being detected by BATS in the device video stream

SDK: `do_add_ocr_roi()`  Notes:  * @@@@ deprecated: 'roi_api/add_roi' will function for OCR ROIs as well, rendering this method redundant.  * The ROI name specified by `roi_name` is presumed to be present in the current ROI definitions file.  * The ROI specified to this method is matched textually after OCR extraction on the ROI; use `add_roi()`    to specify an ROI to be matched using image comparison.  * Once added, ROI matching for the specified ROI ensues immediately; use `match_rois()` to check if an ROI    has been matched in the current video stream.  * CAUTION: Each ROI added to the collection imposes a significant incremental processing burden on BATS;    limit the collection of ROIs being detected concurrently to a manageable set.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.RoiApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
roi_name = 'roi_name_example' # str | Name of OCR ROI definition to begin matching by OCR text

try:
    # Adds an Optical Character Recognition (OCR) Region-Of-Interest (ROI) definition to the collection of ROIs         currently being detected by BATS in the device video stream
    api_instance.do_add_ocr_roi(slot_id, roi_name)
except ApiException as e:
    print("Exception when calling RoiApi->do_add_ocr_roi: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **roi_name** | **str**| Name of OCR ROI definition to begin matching by OCR text | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_add_roi**
> do_add_roi(slot_id, roi_name, thresh=thresh)

Adds a Region-Of-Interest (ROI) definition to the collection of ROIs currently being detected by BATS in the         device video stream

SDK: `do_add_roi()`  Notes:  * The ROI name specified by `roi_name` is presumed to be present in the current ROI definitions file.  * Once added, ROI matching for the specified ROI ensues immediately; use `match_rois()` to check if an ROI    has been matched in the current video stream.  * CAUTION: Each ROI added to the collection imposes a significant incremental processing burden on BATS;    limit the collection of ROIs being detected concurrently to a manageable set.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.RoiApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
roi_name = 'roi_name_example' # str | Name of ROI definition to begin matching by image comparison
thresh = 0.9 # float | For image ROIs, threshold value (0-100%) specifying what percentage of the pixels within                  the ROI must compare successfully to the expected ROI image to qualify as a match (optional) (default to 0.9)

try:
    # Adds a Region-Of-Interest (ROI) definition to the collection of ROIs currently being detected by BATS in the         device video stream
    api_instance.do_add_roi(slot_id, roi_name, thresh=thresh)
except ApiException as e:
    print("Exception when calling RoiApi->do_add_roi: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **roi_name** | **str**| Name of ROI definition to begin matching by image comparison | 
 **thresh** | **float**| For image ROIs, threshold value (0-100%) specifying what percentage of the pixels within                  the ROI must compare successfully to the expected ROI image to qualify as a match | [optional] [default to 0.9]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_add_roi_from_asset**
> str do_add_roi_from_asset(slot_id, urlspec, roi_name, thresh=thresh, region=region, target_frame_num=target_frame_num)

Acquires a particular frame from the stream for an asset, creates a Region-Of-Interest (ROI) for that frame         (or some subset of it), and initiates matching for that ROI

SDK: `do_add_roi_from_asset()`  Notes:  * This is basically a dynamic mechanism to check if certain fragments of asset content are being played    in the current media stream.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.RoiApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
urlspec = 'urlspec_example' # str | URL describing the location of unified media content for the asset, or a pair                          (header, media) of URLs describing the asset media
roi_name = 'roi_name_example' # str | Name to use for ROI created from frame
thresh = 0.9 # float | Threshold value (0-100%) specifying how closely each stream frame must resemble the                          target frame to qualify as a match (optional) (default to 0.9)
region = 'region_example' # str | Region of frame to match ('upper-half' => upper half, None => entire frame) (optional)
target_frame_num = 29 # int | Frame number within asset to use as match target (optional) (default to 29)

try:
    # Acquires a particular frame from the stream for an asset, creates a Region-Of-Interest (ROI) for that frame         (or some subset of it), and initiates matching for that ROI
    api_response = api_instance.do_add_roi_from_asset(slot_id, urlspec, roi_name, thresh=thresh, region=region, target_frame_num=target_frame_num)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RoiApi->do_add_roi_from_asset: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **urlspec** | **str**| URL describing the location of unified media content for the asset, or a pair                          (header, media) of URLs describing the asset media | 
 **roi_name** | **str**| Name to use for ROI created from frame | 
 **thresh** | **float**| Threshold value (0-100%) specifying how closely each stream frame must resemble the                          target frame to qualify as a match | [optional] [default to 0.9]
 **region** | **str**| Region of frame to match (&#x27;upper-half&#x27; &#x3D;&gt; upper half, None &#x3D;&gt; entire frame) | [optional] 
 **target_frame_num** | **int**| Frame number within asset to use as match target | [optional] [default to 29]

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_add_roi_from_image**
> str do_add_roi_from_image(slot_id, filespec, roi_name=roi_name, thresh=thresh, region=region, match=match)

Generates a ROI from an image (or optionally, a portion thereof), and optionally initiates matching for that ROI

SDK: `do_add_roi_from_image()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.RoiApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
filespec = 'filespec_example' # str | File specification of image file to use as a ROI
roi_name = 'roi_name_example' # str | Name to use for ROI created from frame (None => derive ROI name from specified filename) (optional)
thresh = 0.9 # float | Threshold value (0-100%) specifying how closely each stream frame must resemble the                  target frame to qualify as a match (optional) (default to 0.9)
region = 'region_example' # str | Region of frame to match ('upper-half' => upper half, None => entire frame) (optional)
match = true # bool | \"Start matching the newly defined ROI.\" (optional) (default to true)

try:
    # Generates a ROI from an image (or optionally, a portion thereof), and optionally initiates matching for that ROI
    api_response = api_instance.do_add_roi_from_image(slot_id, filespec, roi_name=roi_name, thresh=thresh, region=region, match=match)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RoiApi->do_add_roi_from_image: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **filespec** | **str**| File specification of image file to use as a ROI | 
 **roi_name** | **str**| Name to use for ROI created from frame (None &#x3D;&gt; derive ROI name from specified filename) | [optional] 
 **thresh** | **float**| Threshold value (0-100%) specifying how closely each stream frame must resemble the                  target frame to qualify as a match | [optional] [default to 0.9]
 **region** | **str**| Region of frame to match (&#x27;upper-half&#x27; &#x3D;&gt; upper half, None &#x3D;&gt; entire frame) | [optional] 
 **match** | **bool**| \&quot;Start matching the newly defined ROI.\&quot; | [optional] [default to true]

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_match_rois**
> list[object] do_match_rois(slot_id, roi_names, interval=interval, screenshot_interval=screenshot_interval, timeout=timeout, audio_video_check=audio_video_check)

Determines which of the specified ROI(s) among the collection of ROIs currently being detected by BATS         in the device video stream have been matched

SDK: `do_match_rois()`  Notes:  * The ROI name(s) specified by `roi_names` are all presumed to have been added previously to the collection    of ROIs being detected by BATS via `add_roi()` or `add_ocr_roi()'.  * If multiple ROI names are specified, this method tries to match all ROIs specified, and returns a    collection of matched ROIs.

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.RoiApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
roi_names = 'roi_names_example' # str | Name or collection of names of ROI(s) to check for a match in the playback stream                             (collection => check for multiple ROIs)
interval = 1.0 # float | Time interval (sec) at which to check for ROI match completion (optional) (default to 1.0)
screenshot_interval = 5.0 # float | Time interval (sec) at which to take screenshots (0 => no screenshots) (optional) (default to 5.0)
timeout = 30.0 # float | Timeout (sec) allowed for match check (optional) (default to 30.0)
audio_video_check = false # bool | \"Also check that video and audio are not frozen.\" (optional) (default to false)

try:
    # Determines which of the specified ROI(s) among the collection of ROIs currently being detected by BATS         in the device video stream have been matched
    api_response = api_instance.do_match_rois(slot_id, roi_names, interval=interval, screenshot_interval=screenshot_interval, timeout=timeout, audio_video_check=audio_video_check)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RoiApi->do_match_rois: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **roi_names** | **str**| Name or collection of names of ROI(s) to check for a match in the playback stream                             (collection &#x3D;&gt; check for multiple ROIs) | 
 **interval** | **float**| Time interval (sec) at which to check for ROI match completion | [optional] [default to 1.0]
 **screenshot_interval** | **float**| Time interval (sec) at which to take screenshots (0 &#x3D;&gt; no screenshots) | [optional] [default to 5.0]
 **timeout** | **float**| Timeout (sec) allowed for match check | [optional] [default to 30.0]
 **audio_video_check** | **bool**| \&quot;Also check that video and audio are not frozen.\&quot; | [optional] [default to false]

### Return type

**list[object]**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_match_rois_with_scores**
> list[list[object]] do_match_rois_with_scores(slot_id, roi_names, thresh=thresh, timeout=timeout, audio_video_check=audio_video_check)

Submits a collection of ROIs to BATS for it to match in realtime against the incoming video stream for         a specified duration, using the specified matching threshold, returning all ROIs matched and the match degree         for each

SDK: `do_match_rois_with_scores()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.RoiApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
roi_names = 'roi_names_example' # str | Name or collection of names of ROI(s) to check for a match in the stream                           (collection => check for multiple ROIs)
thresh = 0.9 # float | Threshold value (0-100%) specifying what percentage of the pixels within the ROI                           must compare successfully to the expected ROI image to qualify as a match (optional) (default to 0.9)
timeout = 30.0 # float | Timeout (sec) allowed for match check (optional) (default to 30.0)
audio_video_check = false # bool | \"Also check that video and audio are not frozen.\" (optional) (default to false)

try:
    # Submits a collection of ROIs to BATS for it to match in realtime against the incoming video stream for         a specified duration, using the specified matching threshold, returning all ROIs matched and the match degree         for each
    api_response = api_instance.do_match_rois_with_scores(slot_id, roi_names, thresh=thresh, timeout=timeout, audio_video_check=audio_video_check)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RoiApi->do_match_rois_with_scores: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **roi_names** | **str**| Name or collection of names of ROI(s) to check for a match in the stream                           (collection &#x3D;&gt; check for multiple ROIs) | 
 **thresh** | **float**| Threshold value (0-100%) specifying what percentage of the pixels within the ROI                           must compare successfully to the expected ROI image to qualify as a match | [optional] [default to 0.9]
 **timeout** | **float**| Timeout (sec) allowed for match check | [optional] [default to 30.0]
 **audio_video_check** | **bool**| \&quot;Also check that video and audio are not frozen.\&quot; | [optional] [default to false]

### Return type

**list[list[object]]**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **do_remove_roi**
> bool do_remove_roi(slot_id, roi_name)

Removes a Region-Of-Interest (ROI) definition from the collection of ROIs currently being detected by BATS         in the device video stream

SDK: `do_remove_roi()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.RoiApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
roi_name = 'roi_name_example' # str | Name of ROI definition to cease matching within BATS

try:
    # Removes a Region-Of-Interest (ROI) definition from the collection of ROIs currently being detected by BATS         in the device video stream
    api_response = api_instance.do_remove_roi(slot_id, roi_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RoiApi->do_remove_roi: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **roi_name** | **str**| Name of ROI definition to cease matching within BATS | 

### Return type

**bool**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **set_roi_defs**
> list[object] set_roi_defs(slot_id, roi_defs_filespec=roi_defs_filespec, content=content)

Specifies the file defining all Regions-Of-Interest (ROIs) to detect in the video stream for this device,         and (optionally) returns the ROIs within that file

SDK: `set_roi_defs()`

### Example
```python
from __future__ import print_function
import time
import sdk
from sdk.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = sdk.RoiApi()
slot_id = 'slot_id_example' # str | Slot ID for device as accessible to server
roi_defs_filespec = 'roi_defs_filespec_example' # str | File specification of ROI file to establish (None => previous or default ROI file);                           simple filename => within configured ROI definitions directory (optional)
content = true # bool | \"Return BLOB containing ROIs content.\" (else return filespec where content is stored) (optional) (default to true)

try:
    # Specifies the file defining all Regions-Of-Interest (ROIs) to detect in the video stream for this device,         and (optionally) returns the ROIs within that file
    api_response = api_instance.set_roi_defs(slot_id, roi_defs_filespec=roi_defs_filespec, content=content)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RoiApi->set_roi_defs: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slot_id** | **str**| Slot ID for device as accessible to server | 
 **roi_defs_filespec** | **str**| File specification of ROI file to establish (None &#x3D;&gt; previous or default ROI file);                           simple filename &#x3D;&gt; within configured ROI definitions directory | [optional] 
 **content** | **bool**| \&quot;Return BLOB containing ROIs content.\&quot; (else return filespec where content is stored) | [optional] [default to true]

### Return type

**list[object]**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

