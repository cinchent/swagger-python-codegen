# AnalyzerSettings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**color_tolerance** | **int** | Color \&quot;distance\&quot; (three-color 8-bit absolute) &lt;&#x3D; which pixels deemed \&quot;identical\&quot; | [optional] 
**black_threshold** | **int** | Grayscale threshold (8-bit) &lt;&#x3D; which a pixel deemed \&quot;black\&quot; | [optional] 
**same_image_threshold** | **float** | Threshold, % \&quot;same\&quot; pixels &gt;&#x3D; which two images deemed \&quot;identical\&quot; | [optional] 
**frozen_threshold** | **int** | Threshold, # consecutive \&quot;identical\&quot; frames &gt;&#x3D; which video stream deemed \&quot;frozen\&quot; | [optional] 
**silence_threshold** | **int** | Audio level threshold (16-bit absolute) &lt;&#x3D; which audio deemed \&quot;silent\&quot; | [optional] 
**amplitude_tolerance** | **int** | Audio amplitude tolerance (15-bit absolute delta) &lt;&#x3D; which audio samples deemed \&quot;identical\&quot; | [optional] 
**temporal_tolerance** | **int** | Audio sample window, absolute delta &lt;&#x3D; which audio sample comparison for \&quot;identical\&quot; occurs | [optional] 
**same_sound_threshold** | **float** | Threshold, % \&quot;same\&quot; samples &gt;&#x3D; which audio clips deemed \&quot;identical\&quot; | [optional] 
**mute_threshold** | **int** | Threshold, # consecutive \&quot;silent\&quot; audio clips &gt;&#x3D; which audio stream deemed \&quot;mute\&quot; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

